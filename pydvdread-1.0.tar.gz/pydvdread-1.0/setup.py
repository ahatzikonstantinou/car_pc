#!/usr/bin/env python

from distutils.core import setup, Extension
from distutils.command.build_ext import build_ext
from distutils.command.clean import clean
from distutils.dep_util import newer_group
from distutils.dir_util import remove_tree
from distutils import log
from types import *
import os

def fixso(filepath):
    path, filename = os.path.split(filepath)
    return os.path.join(path, '_' + filename)


# Provide a fix for the .so incorrect filename problem
class my_build_ext(build_ext):
    def build_extension(self, ext):
        sources = ext.sources
        if sources is None or type(sources) not in (ListType, TupleType):
            raise DistutilsSetupError, \
                  ("in 'ext_modules' option (extension '%s'), " +
                   "'sources' must be present and must be " +
                   "a list of source filenames") % ext.name
        sources = list(sources)
        fullname = self.get_ext_fullname(ext.name)
        if self.inplace:
            modpath = string.split(fullname, '.')
            package = string.join(modpath[0:-1], '.')
            base = modpath[-1]
            build_py = self.get_finalized_command('build_py')
            package_dir = build_py.get_package_dir(package)
            ext_filename = os.path.join(package_dir,
                                        self.get_ext_filename(base))
        else:
            ext_filename = os.path.join(self.build_lib,
                                        self.get_ext_filename(fullname))
        depends = sources + ext.depends
        ext_filename = fixso(ext_filename)
        if not (self.force or newer_group(depends, ext_filename, 'newer')):
            log.debug("skipping '%s' extension (up-to-date)", ext.name)
            return
        else:
            log.info("building '%s' extension", ext.name)
        sources = self.swig_sources(sources, ext)
        extra_args = ext.extra_compile_args or []
        macros = ext.define_macros[:]
        for undef in ext.undef_macros:
            macros.append((undef,))
        objects = self.compiler.compile(sources,
                                        output_dir=self.build_temp,
                                        macros=macros,
                                        include_dirs=ext.include_dirs,
                                        debug=self.debug,
                                        extra_postargs=extra_args,
                                        depends=ext.depends)
        self._built_objects = objects[:]
        if ext.extra_objects:
            objects.extend(ext.extra_objects)
        extra_args = ext.extra_link_args or []
        language = ext.language or self.compiler.detect_language(sources)
        self.compiler.link_shared_object(
            objects, ext_filename,
            libraries=self.get_libraries(ext),
            library_dirs=ext.library_dirs,
            runtime_library_dirs=ext.runtime_library_dirs,
            extra_postargs=extra_args,
            export_symbols=self.get_export_symbols(ext),
            debug=self.debug,
            build_temp=self.build_temp,
            target_lang=language)

# Clean more
class my_clean(clean):
    def run(self):
        # Delete build dir
        if os.path.exists(self.build_base):
            remove_tree(self.build_base, dry_run=self.dry_run)
        # Delete dist sir
        if os.path.exists('dist'):
            remove_tree('dist', dry_run=self.dry_run)
        # Delete MANIFEST file
        if os.path.exists('MANIFEST'):
            os.remove('MANIFEST')
        # Delete *~
        self.deletepattern('.', lambda x: x.endswith('~'))
        # Delete src/dvdread/*_wrap.c
        self.deletepattern(os.path.join('src', 'dvdread'), lambda x: x.endswith('_wrap.c'))
        # Delete src/dvdread/*.pyc
        self.deletepattern(os.path.join('src', 'dvdread'), lambda x: x.endswith('.pyc'))
        # Delete src/dvdread/*.so
        self.deletepattern(os.path.join('src', 'dvdread'), lambda x: x.endswith('.so'))
        # Delete src/dvdread/*~
        self.deletepattern(os.path.join('src', 'dvdread'), lambda x: x.endswith('~'))
        # Delete tests/*.pyc
        self.deletepattern('tests', lambda x: x.endswith('.pyc'))
        # Delete tests/*~
        self.deletepattern('tests', lambda x: x.endswith('~'))
    
    def deletepattern(self, path, f):
        dircontents = os.listdir(path)
        filelist = filter(f, dircontents)
        pathlist = map(lambda x: os.path.join(path, x), filelist)
        map(os.remove, pathlist)

setup(name='pydvdread',
      version='1.0',
      description='Python bindings for libdvdread',
      author='Rui Dias',
      author_email='ruijdias@users.sourceforge.net',
      url='http://sourceforge.net/projects/pydvdread/',
      py_modules = ['dvdread.all'],
      package_dir = {'': 'src'},
      packages=['dvdread'],
      ext_modules=[Extension('dvdread.all',
                             ['src/dvdread/all.i'],
                             libraries=['dvdread']
                            )],
      cmdclass = {'build_ext': my_build_ext, 'clean': my_clean}
     )
