# -*- coding: utf-8 -*-

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from all import DVD_VIDEO_LB_LEN, MAX_UDF_FILE_NAME_LEN
from all import DVD_READ_INFO_FILE, DVD_READ_INFO_BACKUP_FILE
from all import DVD_READ_MENU_VOBS, DVD_READ_TITLE_VOBS

from all import dvd_stat_t

from all import DVDVersion, DVDOpen
from all import DVDClose, DVDInit
from all import DVDFinish, DVDFileStat
from all import DVDOpenFile, DVDCloseFile
from all import DVDReadBlocks, DVDFileSeek
from all import DVDReadBytes, DVDFileSize
from all import DVDDiscID, DVDUDFVolumeInfo
from all import DVDISOVolumeInfo, DVDUDFCacheLevel


