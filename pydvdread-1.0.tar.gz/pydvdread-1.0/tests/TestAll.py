#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()


import unittest

import Test_cmd_print
import Test_dvd_reader
import Test_ifo_print
import Test_ifo_read
import Test_ifo_types
import Test_nav_print
import Test_nav_read
import Test_nav_types
import TestStruct_dvd_reader
import TestStruct_ifo_types
import TestStruct_nav_types


# Run all tests
if __name__ == '__main__':
    if len(sys.argv) > 1:
        Test_cmd_print.DVDPATH = sys.argv[1]
        Test_dvd_reader.DVDPATH = sys.argv[1]
        Test_ifo_print.DVDPATH = sys.argv[1]
        Test_ifo_read.DVDPATH = sys.argv[1]
        Test_ifo_types.DVDPATH = sys.argv[1]
        Test_nav_print.DVDPATH = sys.argv[1]
        Test_nav_read.DVDPATH = sys.argv[1]
        Test_nav_types.DVDPATH = sys.argv[1]
    suite = unittest.TestLoader().loadTestsFromModule(Test_cmd_print)
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_dvd_reader))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_ifo_print))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_ifo_read))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_ifo_types))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_nav_print))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_nav_read))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(Test_nav_types))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(TestStruct_dvd_reader))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(TestStruct_ifo_types))
    suite.addTest(unittest.TestLoader().loadTestsFromModule(TestStruct_nav_types))
    unittest.TextTestRunner().run(suite)

