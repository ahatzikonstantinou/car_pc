#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import ifo_print, dvd_reader, ifo_read


class Test1(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo0 = ifo_read.ifoOpen(self.dvd, 0)
        self.ifo = ifo_read.ifoOpen(self.dvd, 1)
    
    def tearDown(self):
        ifo_read.ifoClose(self.ifo0)
        ifo_read.ifoClose(self.ifo)
        dvd_reader.DVDClose(self.dvd)
    
    def test_ifoPrint(self):
        ifo_print.ifoPrint(self.dvd, 1)

    def test_ifoPrint_VMGI_MAT(self):
        ifo_print.ifoPrint_VMGI_MAT(self.ifo0.vmgi_mat)

    def test_ifoPrint_VTSI_MAT(self):
        ifo_print.ifoPrint_VTSI_MAT(self.ifo.vtsi_mat)

    def test_ifoPrint_PTL_MAIT(self):
        if self.ifo0.ptl_mait:
            ifo_print.ifoPrint_PTL_MAIT(self.ifo0.ptl_mait)

    def test_ifoPrint_VTS_ATRT(self):
        ifo_print.ifoPrint_VTS_ATRT(self.ifo0.vts_atrt)

    def test_ifoPrint_TT_SRPT(self):
        ifo_print.ifoPrint_TT_SRPT(self.ifo0.tt_srpt)

    def test_ifoPrint_VTS_PTT_SRPT(self):
        ifo_print.ifoPrint_VTS_PTT_SRPT(self.ifo.vts_ptt_srpt)

    def test_ifoPrint_PGC(self):
        ifo_print.ifoPrint_PGC(self.ifo0.first_play_pgc)

    def test_ifoPrint_PGCIT(self):
        ifo_print.ifoPrint_PGCIT(self.ifo.vts_pgcit)

    def test_ifoPrint_PGCI_UT(self):
        ifo_print.ifoPrint_PGCI_UT(self.ifo.pgci_ut)

    def test_ifoPrint_VTS_TMAPT(self):
        ifo_print.ifoPrint_VTS_TMAPT(self.ifo.vts_tmapt)

    def test_ifoPrint_C_ADT(self):
        ifo_print.ifoPrint_C_ADT(self.ifo.menu_c_adt)

    def test_ifoPrint_VOBU_ADMAP(self):
        ifo_print.ifoPrint_VOBU_ADMAP(self.ifo.menu_vobu_admap)


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

