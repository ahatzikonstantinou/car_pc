#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import dvd_reader


class Test1(unittest.TestCase):
    
    def testConstants(self):
        self.assertRaises(AttributeError, lambda: dvd_reader.DVDREAD_VERSION)
        self.assertEqual(dvd_reader.DVD_VIDEO_LB_LEN, 2048)
        self.assertEqual(dvd_reader.MAX_UDF_FILE_NAME_LEN, 2048)
        self.assert_(isinstance(dvd_reader.DVD_READ_INFO_FILE, int))
        self.assert_(isinstance(dvd_reader.DVD_READ_INFO_BACKUP_FILE, int))
        self.assert_(isinstance(dvd_reader.DVD_READ_MENU_VOBS, int))
        self.assert_(isinstance(dvd_reader.DVD_READ_TITLE_VOBS, int))

    def test_DVDVersion(self):
        self.assert_(isinstance(dvd_reader.DVDVersion(), int))

class Test2(unittest.TestCase):
    
    def tearDown(self):
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDOpen(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.assertNotEqual(self.dvd, None)
        self.assertRaises(RuntimeError, dvd_reader.DVDOpen, '/dev/null')

class Test3(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
    
    def test_DVDClose(self):
        dvd_reader.DVDClose(self.dvd)

class Test4(unittest.TestCase):
    
    def tearDown(self):
        dvd_reader.DVDFinish()
    
    def test_DVDInit(self):
        dvd_reader.DVDInit()

class Test5(unittest.TestCase):
    
    def setUp(self):
        dvd_reader.DVDInit()
    
    def test_DVDFinish(self):
        dvd_reader.DVDFinish()

class Test6(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.stat = dvd_reader.DVDFileStat(self.dvd, 3, dvd_reader.DVD_READ_TITLE_VOBS)

    def tearDown(self):
        dvd_reader.DVDClose(self.dvd)
    
    def test_dvd_stat_t(self):
        self.assert_(isinstance(self.stat.size, int))
        self.assert_(isinstance(self.stat.nr_parts, int))
        self.assert_(isinstance(self.stat.parts_size, list))
        self.assertEqual(len(self.stat.parts_size), 9)
        for elem in self.stat.parts_size:
            self.assert_(isinstance(elem, int))

class Test7(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)

    def tearDown(self):
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDFileStat(self):
        stat = dvd_reader.DVDFileStat(self.dvd, 0, dvd_reader.DVD_READ_INFO_FILE)
        self.assert_(isinstance(stat, dvd_reader.dvd_stat_t))
        self.assertRaises(RuntimeError, dvd_reader.DVDFileStat, None, 0, 0)
    
    def test_DVDDiscID(self):
        md5 = dvd_reader.DVDDiscID(self.dvd)
        self.assert_(isinstance(md5, str))
        self.assertEqual(len(md5), 16)
        self.assertRaises(RuntimeError, dvd_reader.DVDDiscID, None)
    
    def test_DVDUDFVolumeInfo(self):
        volid, volsetid = dvd_reader.DVDUDFVolumeInfo(self.dvd)
        self.assert_(isinstance(volid, str))
        self.assert_(isinstance(volsetid, str))
        self.assert_(len(volid) <= 32)
        self.assertEqual(len(volsetid), 128)
        self.assertRaises(RuntimeError, dvd_reader.DVDUDFVolumeInfo, None)

    def test_DVDISOVolumeInfo(self):
        volid, volsetid = dvd_reader.DVDISOVolumeInfo(self.dvd)
        self.assert_(isinstance(volid, str))
        self.assert_(isinstance(volsetid, str))
        self.assert_(len(volid) <= 33)
        self.assertEqual(len(volsetid), 128)
        self.assertRaises(RuntimeError, dvd_reader.DVDISOVolumeInfo, None)

    def test_DVDUDFCacheLevel(self):
        level = dvd_reader.DVDUDFCacheLevel(self.dvd, -1)
        self.assertEqual(level, 1)
        level = dvd_reader.DVDUDFCacheLevel(self.dvd, 0)
        self.assertEqual(level, 0)

class Test8(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)

    def tearDown(self):
        dvd_reader.DVDCloseFile(self.dvdfile)
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDOpenFile(self):
        self.dvdfile = dvd_reader.DVDOpenFile(self.dvd, 0, dvd_reader.DVD_READ_INFO_FILE)
        self.assertNotEqual(self.dvdfile, None)
        self.assertRaises(RuntimeError, dvd_reader.DVDOpenFile, None, 0, 0)

class Test9(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.dvdfile = dvd_reader.DVDOpenFile(self.dvd, 0, dvd_reader.DVD_READ_INFO_FILE)

    def tearDown(self):
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDCloseFile(self):
        dvd_reader.DVDCloseFile(self.dvdfile)

class Test10(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.dvdfile = dvd_reader.DVDOpenFile(self.dvd, 1, dvd_reader.DVD_READ_TITLE_VOBS)

    def tearDown(self):
        dvd_reader.DVDCloseFile(self.dvdfile)
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDReadBlocks(self):
        block = dvd_reader.DVDReadBlocks(self.dvdfile, 0, 2)
        self.assert_(isinstance(block, str))
        self.assertEqual(len(block), 2 * dvd_reader.DVD_VIDEO_LB_LEN)
        self.assertRaises(RuntimeError, dvd_reader.DVDReadBlocks, None, 1, 1)
    
    def test_DVDFileSize(self):
        size = dvd_reader.DVDFileSize(self.dvdfile)
        self.assert_(isinstance(size, int))
        self.assertRaises(RuntimeError, dvd_reader.DVDFileSize, None)

class Test11(unittest.TestCase):

    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.dvdfile = dvd_reader.DVDOpenFile(self.dvd, 0, dvd_reader.DVD_READ_INFO_FILE)

    def tearDown(self):
        dvd_reader.DVDCloseFile(self.dvdfile)
        dvd_reader.DVDClose(self.dvd)
    
    def test_DVDFileSeek(self):
        num1 = 8
        num2 = dvd_reader.DVDFileSeek(self.dvdfile, num1)
        self.assertEqual(num1, num2)
    
    def test_DVDReadBytes(self):
        bytes = dvd_reader.DVDReadBytes(self.dvdfile, 8)
        self.assert_(isinstance(bytes, str))
        self.assertEqual(len(bytes), 8)
        self.assertRaises(RuntimeError, dvd_reader.DVDReadBytes, None, 1)


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

