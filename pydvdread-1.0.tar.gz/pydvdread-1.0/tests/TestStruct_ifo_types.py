#!/usr/bin/env python
# -*- coding: utf-8 -*-

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()


import unittest
from dvdread import ifo_types


class Test1(unittest.TestCase):
    
    def test_dvd_time_t(self):
        obj = ifo_types.dvd_time_t()
        obj.hour = obj.minute = obj.second = obj.frame_u = 1
        self.assertEqual(obj.hour, 1)
        self.assertEqual(obj.minute, 1)
        self.assertEqual(obj.second, 1)
        self.assertEqual(obj.frame_u, 1)

    def test_vm_cmd_t(self):
        obj = ifo_types.vm_cmd_t()
        obj.set_bytes(0,1)
        self.assertEqual(obj.bytes[0], 1)
        obj.bytes = range(8)
        self.assertEqual(obj.bytes, range(8))

    def test_video_attr_t(self):
        obj = ifo_types.video_attr_t()
        obj.mpeg_version = obj.video_format = obj.display_aspect_ratio = obj.permitted_df = 1
        self.assertEqual(obj.mpeg_version, 1)
        self.assertEqual(obj.video_format, 1)
        self.assertEqual(obj.display_aspect_ratio, 1)
        self.assertEqual(obj.permitted_df, 1)
        obj.line21_cc_1 = obj.line21_cc_2 = obj.unknown1 = obj.bit_rate = 1
        self.assertEqual(obj.line21_cc_1, 1)
        self.assertEqual(obj.line21_cc_2, 1)
        self.assertEqual(obj.unknown1, 1)
        self.assertEqual(obj.bit_rate, 1)
        obj.picture_size = obj.letterboxed = obj.film_mode = 1
        self.assertEqual(obj.picture_size, 1)
        self.assertEqual(obj.letterboxed, 1)
        self.assertEqual(obj.film_mode, 1)

    def test_audio_attr_t(self):
        obj = ifo_types.audio_attr_t()
        obj.audio_format = obj.multichannel_extension = obj.lang_type = obj.application_mode = 1
        self.assertEqual(obj.audio_format, 1)
        self.assertEqual(obj.multichannel_extension, 1)
        self.assertEqual(obj.lang_type, 1)
        self.assertEqual(obj.application_mode, 1)
        obj.quantization = obj.sample_frequency = obj.unknown1 = obj.channels = 1
        self.assertEqual(obj.quantization, 1)
        self.assertEqual(obj.sample_frequency, 1)
        self.assertEqual(obj.unknown1, 1)
        self.assertEqual(obj.channels, 1)
        obj.lang_code = obj.lang_extension = obj.code_extension = obj.unknown3 = 1
        self.assertEqual(obj.lang_code, 1)
        self.assertEqual(obj.lang_extension, 1)
        self.assertEqual(obj.code_extension, 1)
        self.assertEqual(obj.unknown3, 1)
        obj.app_info.karaoke.unknown4 = obj.app_info.karaoke.channel_assignment = 1
        self.assertEqual(obj.app_info.karaoke.unknown4, 1)
        self.assertEqual(obj.app_info.karaoke.channel_assignment, 1)
        obj.app_info.karaoke.version = 1
        self.assertEqual(obj.app_info.karaoke.version, 1)
        obj.app_info.karaoke.mc_intro = obj.app_info.karaoke.mode = 1
        self.assertEqual(obj.app_info.karaoke.mc_intro, 1)
        self.assertEqual(obj.app_info.karaoke.mode, 1)
        obj.app_info.surround.unknown5 = 1
        obj.app_info.surround.dolby_encoded = 1
        obj.app_info.surround.unknown6 = 1
        self.assertEqual(obj.app_info.surround.unknown5, 1)
        self.assertEqual(obj.app_info.surround.dolby_encoded, 1)
        self.assertEqual(obj.app_info.surround.unknown6, 1)

    def test_multichannel_ext_t(self):
        obj = ifo_types.multichannel_ext_t()
        obj.zero1 = obj.ach0_gme = 1
        self.assertEqual(obj.zero1, 1)
        self.assertEqual(obj.ach0_gme, 1)
        obj.zero2 = obj.ach1_gme = 1
        self.assertEqual(obj.zero2, 1)
        self.assertEqual(obj.ach1_gme, 1)
        obj.zero3 = obj.ach2_gv1e = obj.ach2_gv2e = obj.ach2_gm1e = obj.ach2_gm1e = 1
        self.assertEqual(obj.zero3, 1)
        self.assertEqual(obj.ach2_gv1e, 1)
        self.assertEqual(obj.ach2_gv2e, 1)
        self.assertEqual(obj.ach2_gm1e, 1)
        self.assertEqual(obj.ach2_gm1e, 1)
        obj.zero4 = obj.ach3_gv1e = obj.ach3_gv2e = obj.ach3_gmAe = obj.ach3_se2e = 1
        self.assertEqual(obj.zero4, 1)
        self.assertEqual(obj.ach3_gv1e, 1)
        self.assertEqual(obj.ach3_gv2e, 1)
        self.assertEqual(obj.ach3_gmAe, 1)
        self.assertEqual(obj.ach3_se2e, 1)
        obj.zero5 = obj.ach4_gv1e = obj.ach4_gv2e = obj.ach4_gmBe = obj.ach4_seBe = 1
        self.assertEqual(obj.zero5, 1)
        self.assertEqual(obj.ach4_gv1e, 1)
        self.assertEqual(obj.ach4_gv2e, 1)
        self.assertEqual(obj.ach4_gmBe, 1)
        self.assertEqual(obj.ach4_seBe, 1)
        obj.set_zero6(0,1)
        self.assertEqual(obj.zero6[0], 1)
        obj.zero6 = range(19)
        self.assertEqual(obj.zero6, range(19))

    def test_subp_attr_t(self):
        obj = ifo_types.subp_attr_t()
        obj.code_mode = obj.zero1 = obj.type = 1
        self.assertEqual(obj.code_mode, 1)
        self.assertEqual(obj.zero1, 1)
        self.assertEqual(obj.type, 1)
        obj.zero2 = obj.lang_code = obj.lang_extension = obj.code_extension = 1
        self.assertEqual(obj.zero2, 1)
        self.assertEqual(obj.lang_code, 1)
        self.assertEqual(obj.lang_extension, 1)
        self.assertEqual(obj.code_extension, 1)

    def test_pgc_command_tbl_t(self):
        obj = ifo_types.pgc_command_tbl_t()
        obj.nr_of_pre = obj.nr_of_post = obj.nr_of_cell = obj.last_byte = 1
        self.assertEqual(obj.nr_of_pre, 1)
        self.assertEqual(obj.nr_of_post, 1)
        self.assertEqual(obj.nr_of_cell, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.vm_cmd_t(), ifo_types.vm_cmd_t(), ifo_types.vm_cmd_t()]
        for i in range(3):
            temp[i].set_bytes(0,i)
        obj.set_pre_cmds(temp)
        obj.set_post_cmds(temp)
        obj.set_cell_cmds(temp)
        for i in range(3):
            self.assertEqual(obj.pre_cmds(i).bytes[0], i)
            self.assertEqual(obj.post_cmds(i).bytes[0], i)
            self.assertEqual(obj.cell_cmds(i).bytes[0], i)

    def test_cell_playback_t(self):
        obj = ifo_types.cell_playback_t()
        obj.block_mode = obj.block_type = obj.seamless_play = 1
        self.assertEqual(obj.block_mode, 1)
        self.assertEqual(obj.block_type, 1)
        self.assertEqual(obj.seamless_play, 1)
        obj.interleaved = obj.stc_discontinuity = obj.seamless_angle = 1
        self.assertEqual(obj.interleaved, 1)
        self.assertEqual(obj.stc_discontinuity, 1)
        self.assertEqual(obj.seamless_angle, 1)
        obj.playback_mode = obj.restricted = obj.unknown2 = 1
        self.assertEqual(obj.playback_mode, 1)
        self.assertEqual(obj.restricted, 1)
        self.assertEqual(obj.unknown2, 1)
        obj.still_time = obj.cell_cmd_nr = 1
        self.assertEqual(obj.still_time, 1)
        self.assertEqual(obj.cell_cmd_nr, 1)
        obj.playback_time.hour = 0
        temp = ifo_types.dvd_time_t()
        temp.hour = 1
        obj.playback_time = temp
        self.assertEqual(obj.playback_time.hour, 1)
        obj.first_sector = obj.first_ilvu_end_sector = obj.last_vobu_start_sector = obj.last_sector = 1
        self.assertEqual(obj.first_sector, 1)
        self.assertEqual(obj.first_ilvu_end_sector, 1)
        self.assertEqual(obj.last_vobu_start_sector, 1)
        self.assertEqual(obj.last_sector, 1)

    def test_cell_position_t(self):
        obj = ifo_types.cell_position_t()
        obj.vob_id_nr = obj.zero_1 = obj.cell_nr = 1
        self.assertEqual(obj.vob_id_nr, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.cell_nr, 1)

    def test_user_ops_t(self):
        obj = ifo_types.user_ops_t()
        obj.zero = obj.video_pres_mode_change = 1
        self.assertEqual(obj.zero, 1)
        self.assertEqual(obj.video_pres_mode_change, 1)
        obj.karaoke_audio_pres_mode_change = obj.angle_change = obj.subpic_stream_change = 1
        obj.audio_stream_change = obj.pause_on = obj.still_off = obj.button_select_or_activate = 1
        obj.resume = 1
        self.assertEqual(obj.karaoke_audio_pres_mode_change, 1)
        self.assertEqual(obj.angle_change, 1)
        self.assertEqual(obj.subpic_stream_change, 1)
        self.assertEqual(obj.audio_stream_change, 1)
        self.assertEqual(obj.pause_on, 1)
        self.assertEqual(obj.still_off, 1)
        self.assertEqual(obj.button_select_or_activate, 1)
        self.assertEqual(obj.resume, 1)
        obj.chapter_menu_call = obj.angle_menu_call = obj.audio_menu_call = obj.subpic_menu_call = 1
        obj.root_menu_call = obj.title_menu_call = obj.backward_scan = obj.forward_scan = 1
        self.assertEqual(obj.chapter_menu_call, 1)
        self.assertEqual(obj.angle_menu_call, 1)
        self.assertEqual(obj.audio_menu_call, 1)
        self.assertEqual(obj.subpic_menu_call, 1)
        self.assertEqual(obj.root_menu_call, 1)
        self.assertEqual(obj.title_menu_call, 1)
        self.assertEqual(obj.backward_scan, 1)
        self.assertEqual(obj.forward_scan, 1)
        obj.next_pg_search = obj.prev_or_top_pg_search = obj.time_or_chapter_search = obj.go_up = 1
        obj.stop = obj.title_play = obj.chapter_search_or_play = obj.title_or_time_play = 1
        self.assertEqual(obj.next_pg_search, 1)
        self.assertEqual(obj.prev_or_top_pg_search, 1)
        self.assertEqual(obj.time_or_chapter_search, 1)
        self.assertEqual(obj.go_up, 1)
        self.assertEqual(obj.stop, 1)
        self.assertEqual(obj.title_play, 1)
        self.assertEqual(obj.chapter_search_or_play, 1)
        self.assertEqual(obj.title_or_time_play, 1)

    def test_pgc_t(self):
        obj = ifo_types.pgc_t()
        obj.zero_1 = obj.nr_of_programs = obj.nr_of_cells = 1
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.nr_of_programs, 1)
        self.assertEqual(obj.nr_of_cells, 1)
        obj.playback_time.hour = 0
        temp = ifo_types.dvd_time_t()
        temp.hour = 1
        obj.playback_time = temp
        self.assertEqual(obj.playback_time.hour, 1)
        obj.prohibited_ops.resume = 0
        temp = ifo_types.user_ops_t()
        temp.resume = 1
        obj.prohibited_ops = temp
        self.assertEqual(obj.prohibited_ops.resume, 1)
        obj.set_audio_control(0,1)
        self.assertEqual(obj.audio_control[0], 1)
        obj.audio_control = range(8)
        self.assertEqual(obj.audio_control, range(8))
        obj.set_subp_control(0,1)
        self.assertEqual(obj.subp_control[0], 1)
        obj.subp_control = range(32)
        self.assertEqual(obj.subp_control, range(32))
        obj.next_pgc_nr = obj.prev_pgc_nr = obj.goup_pgc_nr = obj.pg_playback_mode = obj.still_time = 1
        self.assertEqual(obj.next_pgc_nr, 1)
        self.assertEqual(obj.prev_pgc_nr, 1)
        self.assertEqual(obj.goup_pgc_nr, 1)
        self.assertEqual(obj.pg_playback_mode, 1)
        self.assertEqual(obj.still_time, 1)
        obj.set_palette(0,1)
        self.assertEqual(obj.palette[0], 1)
        obj.palette = range(16)
        self.assertEqual(obj.palette, range(16))
        obj.command_tbl_offset = obj.program_map_offset = 1
        obj.cell_playback_offset = obj.cell_position_offset = 1
        self.assertEqual(obj.command_tbl_offset, 1)
        self.assertEqual(obj.program_map_offset, 1)
        self.assertEqual(obj.cell_playback_offset, 1)
        self.assertEqual(obj.cell_position_offset, 1)
        obj.command_tbl = None
        self.assertEqual(obj.command_tbl, None)
        obj.command_tbl = ifo_types.pgc_command_tbl_t()
        self.assertNotEqual(obj.command_tbl, None)
        obj.set_program_map(range(3))
        for i in range(3):
            self.assertEqual(obj.program_map(i), i)
        temp = [ifo_types.cell_playback_t(), ifo_types.cell_playback_t(), ifo_types.cell_playback_t()]
        for i in range(3):
            temp[i].last_sector = i
        obj.set_cell_playback(temp)
        for i in range(3):
            self.assertEqual(obj.cell_playback(i).last_sector, i)
        temp = [ifo_types.cell_position_t(), ifo_types.cell_position_t(), ifo_types.cell_position_t()]
        for i in range(3):
            temp[i].cell_nr = i
        obj.set_cell_position(temp)
        for i in range(3):
            self.assertEqual(obj.cell_position(i).cell_nr, i)

    def test_pgci_srp_t(self):
        obj = ifo_types.pgci_srp_t()
        obj.entry_id = obj.block_mode = obj.block_type = obj.unknown1 = 1
        self.assertEqual(obj.entry_id, 1)
        self.assertEqual(obj.block_mode, 1)
        self.assertEqual(obj.block_type, 1)
        self.assertEqual(obj.unknown1, 1)
        obj.ptl_id_mask = obj.pgc_start_byte = 1
        self.assertEqual(obj.ptl_id_mask, 1)
        self.assertEqual(obj.pgc_start_byte, 1)
        obj.pgc = None
        self.assertEqual(obj.pgc, None)
        obj.pgc = ifo_types.pgc_t()
        self.assertNotEqual(obj.pgc, None)

    def test_pgcit_t(self):
        obj = ifo_types.pgcit_t()
        obj.nr_of_pgci_srp = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_pgci_srp, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.pgci_srp_t(), ifo_types.pgci_srp_t(), ifo_types.pgci_srp_t()]
        for i in range(3):
            temp[i].entry_id = i
        obj.set_pgci_srp(temp)
        for i in range(3):
            self.assertEqual(obj.pgci_srp(i).entry_id, i)

    def test_pgci_lu_t(self):
        obj = ifo_types.pgci_lu_t()
        obj.lang_code = obj.lang_extension = obj.exists = obj.lang_start_byte = 1
        self.assertEqual(obj.lang_code, 1)
        self.assertEqual(obj.lang_extension, 1)
        self.assertEqual(obj.exists, 1)
        self.assertEqual(obj.lang_start_byte, 1)
        obj.pgcit = None
        self.assertEqual(obj.pgcit, None)
        obj.pgcit = ifo_types.pgcit_t()
        self.assertNotEqual(obj.pgcit, None)

    def test_pgci_ut_t(self):
        obj = ifo_types.pgci_ut_t()
        obj.nr_of_lus = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_lus, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.pgci_lu_t(), ifo_types.pgci_lu_t(), ifo_types.pgci_lu_t()]
        for i in range(3):
            temp[i].exists = i
        obj.set_lu(temp)
        for i in range(3):
            self.assertEqual(obj.lu(i).exists, i)

    def test_cell_adr_t(self):
        obj = ifo_types.cell_adr_t()
        obj.vob_id = obj.cell_id = obj.zero_1 = obj.start_sector = obj.last_sector = 1
        self.assertEqual(obj.vob_id, 1)
        self.assertEqual(obj.cell_id, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.start_sector, 1)
        self.assertEqual(obj.last_sector, 1)

    def test_c_adt_t(self):
        obj = ifo_types.c_adt_t()
        obj.nr_of_vobs = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_vobs, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.cell_adr_t(), ifo_types.cell_adr_t(), ifo_types.cell_adr_t()]
        for i in range(3):
            temp[i].vob_id = i
        obj.set_cell_adr_table(temp)
        for i in range(3):
            self.assertEqual(obj.cell_adr_table(i).vob_id, i)

    def test_vobu_admap_t(self):
        obj = ifo_types.vobu_admap_t()
        obj.last_byte = 1
        self.assertEqual(obj.last_byte, 1)
        obj.set_vobu_start_sectors(range(3))
        for i in range(3):
            self.assertEqual(obj.vobu_start_sectors(i), i)

    def test_vmgi_mat_t(self):
        obj = ifo_types.vmgi_mat_t()
        obj.vmg_identifier = 'abc'
        self.assertEqual(obj.vmg_identifier, 'abc')
        obj.vmg_last_sector = obj.vmgi_last_sector = obj.zero_2 = 1
        self.assertEqual(obj.vmg_last_sector, 1)
        self.assertEqual(obj.vmgi_last_sector, 1)
        self.assertEqual(obj.zero_2, 1)
        obj.set_zero_1(0,1)
        self.assertEqual(obj.zero_1[0], 1)
        obj.zero_1 = range(12)
        self.assertEqual(obj.zero_1, range(12))
        obj.specification_version = obj.vmg_category = obj.vmg_nr_of_volumes = obj.vmg_this_volume_nr = 1
        self.assertEqual(obj.specification_version, 1)
        self.assertEqual(obj.vmg_category, 1)
        self.assertEqual(obj.vmg_nr_of_volumes, 1)
        self.assertEqual(obj.vmg_this_volume_nr, 1)
        obj.disc_side = 1
        self.assertEqual(obj.disc_side, 1)
        obj.set_zero_3(0,1)
        self.assertEqual(obj.zero_3[0], 1)
        obj.zero_3 = range(19)
        self.assertEqual(obj.zero_3, range(19))
        obj.set_zero_4(0,1)
        self.assertEqual(obj.zero_4[0], 1)
        obj.zero_4 = range(24)
        self.assertEqual(obj.zero_4, range(24))
        obj.set_zero_5(0,1)
        self.assertEqual(obj.zero_5[0], 1)
        obj.zero_5 = range(56)
        self.assertEqual(obj.zero_5, range(56))
        obj.set_zero_6(0,1)
        self.assertEqual(obj.zero_6[0], 1)
        obj.zero_6 = range(32)
        self.assertEqual(obj.zero_6, range(32))
        obj.provider_identifier = 'abc'
        self.assertEqual(obj.provider_identifier, 'abc')
        obj.vmg_nr_of_title_sets = obj.vmg_pos_code = obj.vmgi_last_byte = obj.first_play_pgc = 1
        obj.vmgm_vobs = obj.tt_srpt = obj.vmgm_pgci_ut = obj.ptl_mait = 1
        obj.vts_atrt = obj.txtdt_mgi = obj.vmgm_c_adt = obj.vmgm_vobu_admap = 1
        self.assertEqual(obj.vmg_nr_of_title_sets, 1)
        self.assertEqual(obj.vmg_pos_code, 1)
        self.assertEqual(obj.vmgi_last_byte, 1)
        self.assertEqual(obj.first_play_pgc, 1)
        self.assertEqual(obj.vmgm_vobs, 1)
        self.assertEqual(obj.tt_srpt, 1)
        self.assertEqual(obj.vmgm_pgci_ut, 1)
        self.assertEqual(obj.ptl_mait, 1)
        self.assertEqual(obj.vts_atrt, 1)
        self.assertEqual(obj.txtdt_mgi, 1)
        self.assertEqual(obj.vmgm_c_adt, 1)
        self.assertEqual(obj.vmgm_vobu_admap, 1)
        temp = ifo_types.video_attr_t()
        temp.unknown1 = 1
        obj.vmgm_video_attr.unknown1 = 0
        obj.vmgm_video_attr = temp
        self.assertEqual(obj.vmgm_video_attr.unknown1, 1)
        obj.zero_7 = obj.nr_of_vmgm_audio_streams = 1
        self.assertEqual(obj.zero_7, 1)
        self.assertEqual(obj.nr_of_vmgm_audio_streams, 1)
        temp = ifo_types.audio_attr_t()
        temp.unknown3 = 1
        obj.vmgm_audio_attr.unknown3 = 0
        obj.vmgm_audio_attr = temp
        self.assertEqual(obj.vmgm_audio_attr.unknown3, 1)
        temp = ifo_types.audio_attr_t()
        temp.unknown3 = 1
        obj.zero_8[0].unknown3 = 0
        obj.set_zero_8(0, temp)
        self.assertEqual(obj.zero_8[0].unknown3, 1)
        temp = []
        for i in range(7):
            temp.append(ifo_types.audio_attr_t())
            temp[i].unknown3 = i
        obj.zero_8 = temp
        for i in range(7):
            self.assertEqual(obj.zero_8[i].unknown3, i)
        obj.set_zero_9(0,1)
        self.assertEqual(obj.zero_9[0], 1)
        obj.zero_9 = range(17)
        self.assertEqual(obj.zero_9, range(17))
        obj.nr_of_vmgm_subp_streams = 1
        self.assertEqual(obj.nr_of_vmgm_subp_streams, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.vmgm_subp_attr.lang_code = 0
        obj.vmgm_subp_attr = temp
        self.assertEqual(obj.vmgm_subp_attr.lang_code, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.zero_10[0].lang_code = 0
        obj.set_zero_10(0, temp)
        self.assertEqual(obj.zero_10[0].lang_code, 1)
        temp = []
        for i in range(27):
            temp.append(ifo_types.subp_attr_t())
            temp[i].lang_code = i
        obj.zero_10 = temp
        for i in range(27):
            self.assertEqual(obj.zero_10[i].lang_code, i)

    def test_playback_type_t(self):
        obj = ifo_types.playback_type_t()
        obj.zero_1 = obj.multi_or_random_pgc_title = 1
        obj.jlc_exists_in_cell_cmd = obj.jlc_exists_in_prepost_cmd = 1
        obj.jlc_exists_in_button_cmd = obj.jlc_exists_in_tt_dom = 1
        obj.chapter_search_or_play = obj.title_or_time_play = 1
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.multi_or_random_pgc_title, 1)
        self.assertEqual(obj.jlc_exists_in_cell_cmd, 1)
        self.assertEqual(obj.jlc_exists_in_prepost_cmd, 1)
        self.assertEqual(obj.jlc_exists_in_button_cmd, 1)
        self.assertEqual(obj.jlc_exists_in_tt_dom, 1)
        self.assertEqual(obj.chapter_search_or_play, 1)
        self.assertEqual(obj.title_or_time_play, 1)

    def test_title_info_t(self):
        obj = ifo_types.title_info_t()
        temp = ifo_types.playback_type_t()
        temp.title_or_time_play = 1
        obj.pb_ty.title_or_time_play = 0
        obj.pb_ty = temp
        self.assertEqual(obj.pb_ty.title_or_time_play, 1)
        obj.nr_of_angles = obj.nr_of_ptts = obj.parental_id = 1
        obj.title_set_nr = obj.vts_ttn = obj.title_set_sector = 1
        self.assertEqual(obj.nr_of_angles, 1)
        self.assertEqual(obj.nr_of_ptts, 1)
        self.assertEqual(obj.parental_id, 1)
        self.assertEqual(obj.title_set_nr, 1)
        self.assertEqual(obj.vts_ttn, 1)
        self.assertEqual(obj.title_set_sector, 1)

    def test_tt_srpt_t(self):
        obj = ifo_types.tt_srpt_t()
        obj.nr_of_srpts = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_srpts, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.title_info_t(), ifo_types.title_info_t(), ifo_types.title_info_t()]
        for i in range(3):
            temp[i].vts_ttn = i
        obj.set_title(temp)
        for i in range(3):
            self.assertEqual(obj.title(i).vts_ttn, i)

    def test_ptl_mait_country_t(self):
        obj = ifo_types.ptl_mait_country_t()
        obj.country_code = obj.zero_1 = obj.pf_ptl_mai_start_byte = obj.zero_2 = 1
        self.assertEqual(obj.country_code, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.pf_ptl_mai_start_byte, 1)
        self.assertEqual(obj.zero_2, 1)
        temp = [range(8), range(8), range(8)]
        obj.set_pf_ptl_mai(temp)
        for i in range(3):
            self.assertEqual(obj.pf_ptl_mai(i), range(8))

    def test_ptl_mait_t(self):
        obj = ifo_types.ptl_mait_t()
        obj.nr_of_countries = obj.nr_of_vtss = obj.last_byte = 1
        self.assertEqual(obj.nr_of_countries, 1)
        self.assertEqual(obj.nr_of_vtss, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.ptl_mait_country_t(), ifo_types.ptl_mait_country_t(),
                ifo_types.ptl_mait_country_t()]
        for i in range(3):
            temp[i].country_code = i
        obj.set_countries(temp)
        for i in range(3):
            self.assertEqual(obj.countries(i).country_code, i)

    def test_vts_attributes_t(self):
        obj = ifo_types.vts_attributes_t()
        obj.last_byte = obj.vts_cat = 1
        self.assertEqual(obj.last_byte, 1)
        self.assertEqual(obj.vts_cat, 1)
        temp = ifo_types.video_attr_t()
        temp.unknown1 = 1
        obj.vtsm_vobs_attr.unknown1 = 0
        obj.vtsm_vobs_attr = temp
        self.assertEqual(obj.vtsm_vobs_attr.unknown1, 1)
        obj.zero_1 = obj.nr_of_vtsm_audio_streams = 1
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.nr_of_vtsm_audio_streams, 1)
        temp = ifo_types.audio_attr_t()
        temp.unknown1 = 1
        obj.vtsm_audio_attr.unknown1 = 0
        obj.vtsm_audio_attr = temp
        self.assertEqual(obj.vtsm_audio_attr.unknown1, 1)
        temp = ifo_types.audio_attr_t()
        temp.unknown3 = 1
        obj.zero_2[0].unknown3 = 0
        obj.set_zero_2(0, temp)
        self.assertEqual(obj.zero_2[0].unknown3, 1)
        temp = []
        for i in range(7):
            temp.append(ifo_types.audio_attr_t())
            temp[i].unknown3 = i
        obj.zero_2 = temp
        for i in range(7):
            self.assertEqual(obj.zero_2[i].unknown3, i)
        obj.set_zero_3(0, 1)
        self.assertEqual(obj.zero_3[0], 1)
        obj.zero_3 = range(16)
        self.assertEqual(obj.zero_3, range(16))
        obj.zero_4 = obj.nr_of_vtsm_subp_streams = 1
        self.assertEqual(obj.zero_4, 1)
        self.assertEqual(obj.nr_of_vtsm_subp_streams, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.vtsm_subp_attr.lang_code = 0
        obj.vtsm_subp_attr = temp
        self.assertEqual(obj.vtsm_subp_attr.lang_code, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.zero_5[0].lang_code = 0
        obj.set_zero_5(0, temp)
        self.assertEqual(obj.zero_5[0].lang_code, 1)
        temp = []
        for i in range(27):
            temp.append(ifo_types.subp_attr_t())
            temp[i].lang_code = i
        obj.zero_5 = temp
        for i in range(27):
            self.assertEqual(obj.zero_5[i].lang_code, i)
        obj.set_zero_6(0, 1)
        self.assertEqual(obj.zero_6[0], 1)
        obj.zero_6 = range(2)
        self.assertEqual(obj.zero_6, range(2))
        temp = ifo_types.video_attr_t()
        temp.unknown1 = 1
        obj.vtstt_vobs_video_attr.unknown1 = 0
        obj.vtstt_vobs_video_attr = temp
        self.assertEqual(obj.vtstt_vobs_video_attr.unknown1, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.vtstt_subp_attr[0].lang_code = 0
        obj.set_vtstt_subp_attr(0, temp)
        self.assertEqual(obj.vtstt_subp_attr[0].lang_code, 1)
        temp = []
        for i in range(32):
            temp.append(ifo_types.subp_attr_t())
            temp[i].lang_code = i
        obj.vtstt_subp_attr = temp
        for i in range(32):
            self.assertEqual(obj.vtstt_subp_attr[i].lang_code, i)
        temp = ifo_types.audio_attr_t()
        temp.unknown3 = 1
        obj.vtstt_audio_attr[0].unknown3 = 0
        obj.set_vtstt_audio_attr(0, temp)
        self.assertEqual(obj.vtstt_audio_attr[0].unknown3, 1)
        temp = []
        for i in range(8):
            temp.append(ifo_types.audio_attr_t())
            temp[i].unknown3 = i
        obj.vtstt_audio_attr = temp
        for i in range(8):
            self.assertEqual(obj.vtstt_audio_attr[i].unknown3, i)
        obj.set_zero_8(0, 1)
        self.assertEqual(obj.zero_8[0], 1)
        obj.zero_8 = range(16)
        self.assertEqual(obj.zero_8, range(16))
        obj.zero_7 = obj.nr_of_vtstt_audio_streams = obj.zero_9 = obj.nr_of_vtstt_subp_streams = 1
        self.assertEqual(obj.zero_7, 1)
        self.assertEqual(obj.nr_of_vtstt_audio_streams, 1)
        self.assertEqual(obj.zero_9, 1)
        self.assertEqual(obj.nr_of_vtstt_subp_streams, 1)

    def test_vts_atrt_t(self):
        obj = ifo_types.vts_atrt_t()
        obj.nr_of_vtss = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_vtss, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.vts_attributes_t(), ifo_types.vts_attributes_t(), ifo_types.vts_attributes_t()]
        for i in range(3):
            temp[i].last_byte = i
        obj.set_vts(temp)
        for i in range(3):
            self.assertEqual(obj.vts(i).last_byte, i)
        obj.set_vts_atrt_offsets(range(3))
        for i in range(3):
            self.assertEqual(obj.vts_atrt_offsets(i), i)

    def test_txtdt_t(self):
        obj = ifo_types.txtdt_t()
        obj.last_byte = 1
        self.assertEqual(obj.last_byte, 1)
        obj.set_offsets(0, 1)
        self.assertEqual(obj.offsets[0], 1)
        obj.offsets = range(100)
        self.assertEqual(obj.offsets, range(100))

    def test_txtdt_lu_t(self):
        obj = ifo_types.txtdt_lu_t()
        obj.lang_code = obj.unknown = obj.txtdt_start_byte = 1
        self.assertEqual(obj.lang_code, 1)
        self.assertEqual(obj.unknown, 1)
        self.assertEqual(obj.txtdt_start_byte, 1)
        obj.txtdt = None
        self.assertEqual(obj.txtdt, None)
        obj.txtdt = ifo_types.txtdt_t()
        self.assertNotEqual(obj.txtdt, None)

    def test_txtdt_mgi_t(self):
        obj = ifo_types.txtdt_mgi_t()
        obj.disc_name = 'abc'
        self.assertEqual(obj.disc_name, 'abc')
        obj.nr_of_language_units = obj.last_byte = 1
        self.assertEqual(obj.nr_of_language_units, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.txtdt_lu_t(), ifo_types.txtdt_lu_t(), ifo_types.txtdt_lu_t()]
        for i in range(3):
            temp[i].unknown = i
        obj.set_lu(temp)
        for i in range(3):
            self.assertEqual(obj.lu(i).unknown, i)

    def test_vtsi_mat_t(self):
        obj = ifo_types.vtsi_mat_t()
        obj.vts_identifier = 'abc'
        self.assertEqual(obj.vts_identifier, 'abc')
        obj.vts_last_sector = 1
        self.assertEqual(obj.vts_last_sector, 1)
        obj.set_zero_1(0, 1)
        self.assertEqual(obj.zero_1[0], 1)
        obj.zero_1 = range(12)
        self.assertEqual(obj.zero_1, range(12))
        obj.set_zero_6(0, 1)
        self.assertEqual(obj.zero_6[0], 1)
        obj.zero_6 = range(19)
        self.assertEqual(obj.zero_6, range(19))
        obj.set_zero_8(0, 1)
        self.assertEqual(obj.zero_8[0], 1)
        obj.zero_8 = range(32)
        self.assertEqual(obj.zero_8, range(32))
        obj.set_zero_10(0, 1)
        self.assertEqual(obj.zero_10[0], 1)
        obj.zero_10 = range(24)
        self.assertEqual(obj.zero_10, range(24))
        obj.set_zero_13(0, 1)
        self.assertEqual(obj.zero_13[0], 1)
        obj.zero_13 = range(24)
        self.assertEqual(obj.zero_13, range(24))
        obj.set_zero_12(0, 1)
        self.assertEqual(obj.zero_12[0], 1)
        obj.zero_12 = range(56)
        self.assertEqual(obj.zero_12, range(56))
        obj.vtsi_last_sector = obj.zero_2 = obj.specification_version = obj.vts_category = 1
        self.assertEqual(obj.vtsi_last_sector, 1)
        self.assertEqual(obj.zero_2, 1)
        self.assertEqual(obj.specification_version, 1)
        self.assertEqual(obj.vts_category, 1)
        obj.zero_3 = obj.zero_4 = obj.zero_5 = obj.zero_7 = 1
        self.assertEqual(obj.zero_3, 1)
        self.assertEqual(obj.zero_4, 1)
        self.assertEqual(obj.zero_5, 1)
        self.assertEqual(obj.zero_7, 1)
        obj.vtsm_c_adt = obj.vtsm_vobu_admap = obj.vts_c_adt = obj.vts_vobu_admap = 1
        self.assertEqual(obj.vtsm_c_adt, 1)
        self.assertEqual(obj.vtsm_vobu_admap, 1)
        self.assertEqual(obj.vts_c_adt, 1)
        self.assertEqual(obj.vts_vobu_admap, 1)
        obj.zero_9 = obj.vtsi_last_byte = obj.zero_11 = 1
        self.assertEqual(obj.zero_9, 1)
        self.assertEqual(obj.vtsi_last_byte, 1)
        self.assertEqual(obj.zero_11, 1)
        obj.vtsm_vobs = obj.vtstt_vobs = obj.vts_ptt_srpt = 1
        self.assertEqual(obj.vtsm_vobs, 1)
        self.assertEqual(obj.vtstt_vobs, 1)
        self.assertEqual(obj.vts_ptt_srpt, 1)
        obj.vts_pgcit = obj.vtsm_pgci_ut = obj.vtsm_pgci_ut = 1
        self.assertEqual(obj.vts_pgcit, 1)
        self.assertEqual(obj.vtsm_pgci_ut, 1)
        self.assertEqual(obj.vtsm_pgci_ut, 1)
        obj.zero_14 = obj.nr_of_vtsm_audio_streams = obj.nr_of_vtsm_subp_streams = 1
        self.assertEqual(obj.zero_14, 1)
        self.assertEqual(obj.nr_of_vtsm_audio_streams, 1)
        self.assertEqual(obj.nr_of_vtsm_subp_streams, 1)
        obj.zero_19 = obj.nr_of_vts_audio_streams = obj.nr_of_vts_subp_streams = obj.zero_21 = 1
        self.assertEqual(obj.zero_19, 1)
        self.assertEqual(obj.nr_of_vts_audio_streams, 1)
        self.assertEqual(obj.nr_of_vts_subp_streams, 1)
        self.assertEqual(obj.zero_21, 1)
        obj.set_zero_16(0, 1)
        self.assertEqual(obj.zero_16[0], 1)
        obj.zero_16 = range(17)
        self.assertEqual(obj.zero_16, range(17))
        obj.set_zero_18(0, 1)
        self.assertEqual(obj.zero_18[0], 1)
        obj.zero_18 = range(2)
        self.assertEqual(obj.zero_18, range(2))
        obj.set_zero_20(0, 1)
        self.assertEqual(obj.zero_20[0], 1)
        obj.zero_20 = range(17)
        self.assertEqual(obj.zero_20, range(17))
        temp = ifo_types.video_attr_t()
        temp.unknown1 = 1
        obj.vtsm_video_attr.unknown1 = 0
        obj.vtsm_video_attr = temp
        self.assertEqual(obj.vtsm_video_attr.unknown1, 1)
        temp = ifo_types.video_attr_t()
        temp.unknown1 = 1
        obj.vts_video_attr.unknown1 = 0
        obj.vts_video_attr = temp
        self.assertEqual(obj.vts_video_attr.unknown1, 1)
        temp = ifo_types.audio_attr_t()
        temp.unknown1 = 1
        obj.vtsm_audio_attr.unknown1 = 0
        obj.vtsm_audio_attr = temp
        self.assertEqual(obj.vtsm_audio_attr.unknown1, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.vtsm_subp_attr.lang_code = 0
        obj.vtsm_subp_attr = temp
        self.assertEqual(obj.vtsm_subp_attr.lang_code, 1)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.zero_17[0].lang_code = 0
        obj.set_zero_17(0, temp)
        self.assertEqual(obj.zero_17[0].lang_code, 1)
        temp = []
        for i in range(27):
            temp.append(ifo_types.subp_attr_t())
            temp[i].lang_code = i
        obj.zero_17 = temp
        for i in range(27):
            self.assertEqual(obj.zero_17[i].lang_code, i)
        temp = ifo_types.audio_attr_t()
        temp.lang_code = 1
        obj.vts_audio_attr[0].lang_code = 0
        obj.set_vts_audio_attr(0, temp)
        self.assertEqual(obj.vts_audio_attr[0].lang_code, 1)
        temp = []
        for i in range(8):
            temp.append(ifo_types.audio_attr_t())
            temp[i].lang_code = i
        obj.vts_audio_attr = temp
        for i in range(8):
            self.assertEqual(obj.vts_audio_attr[i].lang_code, i)
        temp = ifo_types.subp_attr_t()
        temp.lang_code = 1
        obj.vts_subp_attr[0].lang_code = 0
        obj.set_vts_subp_attr(0, temp)
        self.assertEqual(obj.vts_subp_attr[0].lang_code, 1)
        temp = []
        for i in range(32):
            temp.append(ifo_types.subp_attr_t())
            temp[i].lang_code = i
        obj.vts_subp_attr = temp
        for i in range(32):
            self.assertEqual(obj.vts_subp_attr[i].lang_code, i)
        temp = ifo_types.multichannel_ext_t()
        temp.zero1 = 1
        obj.vts_mu_audio_attr[0].zero1 = 0
        obj.set_vts_mu_audio_attr(0, temp)
        self.assertEqual(obj.vts_mu_audio_attr[0].zero1, 1)
        temp = []
        for i in range(8):
            temp.append(ifo_types.multichannel_ext_t())
            temp[i].zero1 = i
        obj.vts_mu_audio_attr = temp
        for i in range(8):
            self.assertEqual(obj.vts_mu_audio_attr[i].zero1, i)

    def test_ptt_info_t(self):
        obj = ifo_types.ptt_info_t()
        obj.pgcn = obj.pgn = 1
        self.assertEqual(obj.pgcn, 1)
        self.assertEqual(obj.pgn, 1)

    def test_ttu_t(self):
        obj = ifo_types.ttu_t()
        obj.nr_of_ptts = 1
        self.assertEqual(obj.nr_of_ptts, 1)
        temp = [ifo_types.ptt_info_t(), ifo_types.ptt_info_t(), ifo_types.ptt_info_t()]
        for i in range(3):
            temp[i].pgn = i
        obj.set_ptt(temp)
        for i in range(3):
            self.assertEqual(obj.ptt(i).pgn, i)

    def test_vts_ptt_srpt_t(self):
        obj = ifo_types.vts_ptt_srpt_t()
        obj.nr_of_srpts = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_srpts, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.ttu_t(), ifo_types.ttu_t(), ifo_types.ttu_t()]
        for i in range(3):
            temp[i].nr_of_ptts = i
        obj.set_title(temp)
        for i in range(3):
            self.assertEqual(obj.title(i).nr_of_ptts, i)
        obj.set_ttu_offset(range(3))
        for i in range(3):
            self.assertEqual(obj.ttu_offset(i), i)

    def test_vts_tmap_t(self):
        obj = ifo_types.vts_tmap_t()
        obj.tmu = obj.zero_1 = obj.nr_of_entries = 1
        self.assertEqual(obj.tmu, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.nr_of_entries, 1)
        obj.set_map_ent(range(3))
        for i in range(3):
            self.assertEqual(obj.map_ent(i), i)

    def test_vts_tmapt_t(self):
        obj = ifo_types.vts_tmapt_t()
        obj.nr_of_tmaps = obj.zero_1 = obj.last_byte = 1
        self.assertEqual(obj.nr_of_tmaps, 1)
        self.assertEqual(obj.zero_1, 1)
        self.assertEqual(obj.last_byte, 1)
        temp = [ifo_types.vts_tmap_t(), ifo_types.vts_tmap_t(), ifo_types.vts_tmap_t()]
        for i in range(3):
            temp[i].tmu = i
        obj.set_tmap(temp)
        for i in range(3):
            self.assertEqual(obj.tmap(i).tmu, i)
        obj.set_tmap_offset(range(3))
        for i in range(3):
            self.assertEqual(obj.tmap_offset(i), i)

    def test_ifo_handle_t(self):
        obj = ifo_types.ifo_handle_t()
        obj.file = None
        self.assertEqual(obj.file, None)
        obj.vmgi_mat = None
        self.assertEqual(obj.vmgi_mat, None)
        obj.vmgi_mat = ifo_types.vmgi_mat_t()
        self.assertNotEqual(obj.vmgi_mat, None)
        obj.tt_srpt = None
        self.assertEqual(obj.tt_srpt, None)
        obj.tt_srpt = ifo_types.tt_srpt_t()
        self.assertNotEqual(obj.tt_srpt, None)
        obj.first_play_pgc = None
        self.assertEqual(obj.first_play_pgc, None)
        obj.first_play_pgc = ifo_types.pgc_t()
        self.assertNotEqual(obj.first_play_pgc, None)
        obj.ptl_mait = None
        self.assertEqual(obj.ptl_mait, None)
        obj.ptl_mait = ifo_types.ptl_mait_t()
        self.assertNotEqual(obj.ptl_mait, None)
        obj.vts_atrt = None
        self.assertEqual(obj.vts_atrt, None)
        obj.vts_atrt = ifo_types.vts_atrt_t()
        self.assertNotEqual(obj.vts_atrt, None)
        obj.txtdt_mgi = None
        self.assertEqual(obj.txtdt_mgi, None)
        obj.txtdt_mgi = ifo_types.txtdt_mgi_t()
        self.assertNotEqual(obj.txtdt_mgi, None)
        obj.pgci_ut = None
        self.assertEqual(obj.pgci_ut, None)
        obj.pgci_ut = ifo_types.pgci_ut_t()
        self.assertNotEqual(obj.pgci_ut, None)
        obj.menu_c_adt = None
        self.assertEqual(obj.menu_c_adt, None)
        obj.menu_c_adt = ifo_types.c_adt_t()
        self.assertNotEqual(obj.menu_c_adt, None)
        obj.menu_vobu_admap = None
        self.assertEqual(obj.menu_vobu_admap, None)
        obj.menu_vobu_admap = ifo_types.vobu_admap_t()
        self.assertNotEqual(obj.menu_vobu_admap, None)
        obj.vtsi_mat = None
        self.assertEqual(obj.vtsi_mat, None)
        obj.vtsi_mat = ifo_types.vtsi_mat_t()
        self.assertNotEqual(obj.vtsi_mat, None)
        obj.vts_ptt_srpt = None
        self.assertEqual(obj.vts_ptt_srpt, None)
        obj.vts_ptt_srpt = ifo_types.vts_ptt_srpt_t()
        self.assertNotEqual(obj.vts_ptt_srpt, None)
        obj.vts_pgcit = None
        self.assertEqual(obj.vts_pgcit, None)
        obj.vts_pgcit = ifo_types.pgcit_t()
        self.assertNotEqual(obj.vts_pgcit, None)
        obj.vts_tmapt = None
        self.assertEqual(obj.vts_tmapt, None)
        obj.vts_tmapt = ifo_types.vts_tmapt_t()
        self.assertNotEqual(obj.vts_tmapt, None)
        obj.vts_c_adt = None
        self.assertEqual(obj.vts_c_adt, None)
        obj.vts_c_adt = ifo_types.c_adt_t()
        self.assertNotEqual(obj.vts_c_adt, None)
        obj.c_adt_t = None
        self.assertEqual(obj.c_adt_t, None)
        obj.c_adt_t = ifo_types.vobu_admap_t()
        self.assertNotEqual(obj.c_adt_t, None)


# Run the tests
if __name__ == '__main__':
    unittest.main()




