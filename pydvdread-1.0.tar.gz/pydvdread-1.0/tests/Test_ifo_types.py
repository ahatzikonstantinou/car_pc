#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import ifo_types, ifo_read, dvd_reader


class Test1(unittest.TestCase):
    
    def testConstants(self):
        self.assertEqual(ifo_types.COMMAND_DATA_SIZE, 8)
        self.assertEqual(ifo_types.PGC_COMMAND_TBL_SIZE, 8)
        self.assertEqual(ifo_types.BLOCK_TYPE_NONE, 0)
        self.assertEqual(ifo_types.BLOCK_TYPE_ANGLE_BLOCK, 1)
        self.assertEqual(ifo_types.BLOCK_MODE_NOT_IN_BLOCK, 0)
        self.assertEqual(ifo_types.BLOCK_MODE_FIRST_CELL, 1)
        self.assertEqual(ifo_types.BLOCK_MODE_IN_BLOCK, 2)
        self.assertEqual(ifo_types.BLOCK_MODE_LAST_CELL, 3)
        self.assertEqual(ifo_types.PGC_SIZE, 236)
        self.assertEqual(ifo_types.PGCI_SRP_SIZE, 8)
        self.assertEqual(ifo_types.PGCIT_SIZE, 8)
        self.assertEqual(ifo_types.PGCI_LU_SIZE, 8)
        self.assertEqual(ifo_types.PGCI_UT_SIZE, 8)
        self.assertEqual(ifo_types.C_ADT_SIZE, 8)
        self.assertEqual(ifo_types.VOBU_ADMAP_SIZE, 4)
        self.assertEqual(ifo_types.TT_SRPT_SIZE, 8)
        self.assertEqual(ifo_types.PTL_MAIT_COUNTRY_SIZE, 8)
        self.assertEqual(ifo_types.PTL_MAIT_SIZE, 8)
        self.assertEqual(ifo_types.VTS_ATTRIBUTES_SIZE, 542)
        self.assertEqual(ifo_types.VTS_ATTRIBUTES_MIN_SIZE, 356)
        self.assertEqual(ifo_types.VTS_ATRT_SIZE, 8)
        self.assertEqual(ifo_types.TXTDT_LU_SIZE, 8)
        self.assertEqual(ifo_types.TXTDT_MGI_SIZE, 20)
        self.assertEqual(ifo_types.VTS_PTT_SRPT_SIZE, 8)
        self.assertEqual(ifo_types.VTS_TMAP_SIZE, 4)
        self.assertEqual(ifo_types.VTS_TMAPT_SIZE, 8)

class Test2(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo0 = ifo_read.ifoOpen(self.dvd, 0)
        self.ifo = ifo_read.ifoOpen(self.dvd, 1)
    
    def tearDown(self):
        ifo_read.ifoClose(self.ifo)
        ifo_read.ifoClose(self.ifo0)
        dvd_reader.DVDClose(self.dvd)

    def testStructs(self):
        ifo_handle_t(self.ifo0, self)
        ifo_handle_t(self.ifo, self)

class Test3(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifos = [ifo_read.ifoOpen(self.dvd, 0)]
        for i in range(1, self.ifos[0].vts_atrt.nr_of_vtss + 1):
            self.ifos.append(ifo_read.ifoOpen(self.dvd, i))
    
    def tearDown(self):
        for ifo in self.ifos:
            ifo_read.ifoClose(ifo)
        dvd_reader.DVDClose(self.dvd)

    def testStructs(self):
        for ifo in self.ifos:
            ifo_handle_t(ifo, self)


# Helper functions

def dvd_time_t(obj, tester):
    tester.assert_(isinstance(obj.hour, int))
    tester.assert_(isinstance(obj.minute, int))
    tester.assert_(isinstance(obj.second, int))
    tester.assert_(isinstance(obj.frame_u, int))

def vm_cmd_t(obj, tester):
    tester.assert_(isinstance(obj.bytes, list))
    tester.assertEqual(len(obj.bytes), 8)
    for elem in obj.bytes:
        tester.assert_(isinstance(elem, int))

def video_attr_t(obj, tester):
    tester.assert_(isinstance(obj.mpeg_version, int))
    tester.assert_(isinstance(obj.video_format, int))
    tester.assert_(isinstance(obj.display_aspect_ratio, int))
    tester.assert_(isinstance(obj.permitted_df, int))
    tester.assert_(isinstance(obj.line21_cc_1, int))
    tester.assert_(isinstance(obj.line21_cc_2, int))
    tester.assert_(isinstance(obj.unknown1, int))
    tester.assert_(isinstance(obj.bit_rate, int))
    tester.assert_(isinstance(obj.picture_size, int))
    tester.assert_(isinstance(obj.letterboxed, int))
    tester.assert_(isinstance(obj.film_mode, int))

def audio_attr_t(obj, tester):
    tester.assert_(isinstance(obj.audio_format, int))
    tester.assert_(isinstance(obj.multichannel_extension, int))
    tester.assert_(isinstance(obj.lang_type, int))
    tester.assert_(isinstance(obj.application_mode, int))
    tester.assert_(isinstance(obj.quantization, int))
    tester.assert_(isinstance(obj.sample_frequency, int))
    tester.assert_(isinstance(obj.unknown1, int))
    tester.assert_(isinstance(obj.channels, int))
    tester.assert_(isinstance(obj.lang_code, int))
    tester.assert_(isinstance(obj.lang_extension, int))
    tester.assert_(isinstance(obj.code_extension, int))
    tester.assert_(isinstance(obj.unknown3, int))
    tester.assert_(isinstance(obj.app_info.karaoke.unknown4, int))
    tester.assert_(isinstance(obj.app_info.karaoke.channel_assignment, int))
    tester.assert_(isinstance(obj.app_info.karaoke.version, int))
    tester.assert_(isinstance(obj.app_info.karaoke.mc_intro, int))
    tester.assert_(isinstance(obj.app_info.karaoke.mode, int))
    tester.assert_(isinstance(obj.app_info.surround.unknown5, int))
    tester.assert_(isinstance(obj.app_info.surround.dolby_encoded, int))
    tester.assert_(isinstance(obj.app_info.surround.unknown6, int))

def multichannel_ext_t(obj, tester):
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.ach0_gme, int))
    tester.assert_(isinstance(obj.zero2, int))
    tester.assert_(isinstance(obj.ach1_gme, int))
    tester.assert_(isinstance(obj.zero3, int))
    tester.assert_(isinstance(obj.ach2_gv1e, int))
    tester.assert_(isinstance(obj.ach2_gv2e, int))
    tester.assert_(isinstance(obj.ach2_gm1e, int))
    tester.assert_(isinstance(obj.ach2_gm2e, int))
    tester.assert_(isinstance(obj.zero4, int))
    tester.assert_(isinstance(obj.ach3_gv1e, int))
    tester.assert_(isinstance(obj.ach3_gv2e, int))
    tester.assert_(isinstance(obj.ach3_gmAe, int))
    tester.assert_(isinstance(obj.ach3_se2e, int))
    tester.assert_(isinstance(obj.zero5, int))
    tester.assert_(isinstance(obj.ach4_gv1e, int))
    tester.assert_(isinstance(obj.ach4_gv2e, int))
    tester.assert_(isinstance(obj.ach4_gmBe, int))
    tester.assert_(isinstance(obj.ach4_seBe, int))
    tester.assert_(isinstance(obj.zero6, list))
    tester.assertEqual(len(obj.zero6), 19)
    for elem in obj.zero6:
        tester.assert_(isinstance(elem, int))

def subp_attr_t(obj, tester):
    tester.assert_(isinstance(obj.code_mode, int))
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.type, int))
    tester.assert_(isinstance(obj.zero2, int))
    tester.assert_(isinstance(obj.lang_code, int))
    tester.assert_(isinstance(obj.lang_extension, int))
    tester.assert_(isinstance(obj.code_extension, int))

def pgc_command_tbl_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_pre, int))
    tester.assert_(isinstance(obj.nr_of_post, int))
    tester.assert_(isinstance(obj.nr_of_cell, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.pre_cmds))
    for i in range(obj.nr_of_pre):
        tester.assert_(isinstance(obj.pre_cmds(i), ifo_types.vm_cmd_t))
        vm_cmd_t(obj.pre_cmds(i), tester)
    tester.assert_(callable(obj.post_cmds))
    for i in range(obj.nr_of_post):
        tester.assert_(isinstance(obj.post_cmds(i), ifo_types.vm_cmd_t))
        vm_cmd_t(obj.post_cmds(i), tester)
    tester.assert_(callable(obj.cell_cmds))
    for i in range(obj.nr_of_cell):
        tester.assert_(isinstance(obj.cell_cmds(i), ifo_types.vm_cmd_t))
        vm_cmd_t(obj.cell_cmds(i), tester)


def cell_playback_t(obj, tester):
    tester.assert_(isinstance(obj.block_mode, int))
    tester.assert_(isinstance(obj.block_type, int))
    tester.assert_(isinstance(obj.seamless_play, int))
    tester.assert_(isinstance(obj.interleaved, int))
    tester.assert_(isinstance(obj.stc_discontinuity, int))
    tester.assert_(isinstance(obj.seamless_angle, int))
    tester.assert_(isinstance(obj.playback_mode, int))
    tester.assert_(isinstance(obj.restricted, int))
    tester.assert_(isinstance(obj.unknown2, int))
    tester.assert_(isinstance(obj.still_time, int))
    tester.assert_(isinstance(obj.cell_cmd_nr, int))
    tester.assert_(isinstance(obj.playback_time, ifo_types.dvd_time_t))
    dvd_time_t(obj.playback_time, tester)
    tester.assert_(isinstance(obj.first_sector, int))
    tester.assert_(isinstance(obj.first_ilvu_end_sector, int))
    tester.assert_(isinstance(obj.last_vobu_start_sector, int))
    tester.assert_(isinstance(obj.last_sector, int))

def cell_position_t(obj, tester):
    tester.assert_(isinstance(obj.vob_id_nr, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.cell_nr, int))

def user_ops_t(obj, tester):
    tester.assert_(isinstance(obj.zero, int))
    tester.assert_(isinstance(obj.video_pres_mode_change, int))
    tester.assert_(isinstance(obj.karaoke_audio_pres_mode_change, int))
    tester.assert_(isinstance(obj.angle_change, int))
    tester.assert_(isinstance(obj.subpic_stream_change, int))
    tester.assert_(isinstance(obj.audio_stream_change, int))
    tester.assert_(isinstance(obj.pause_on, int))
    tester.assert_(isinstance(obj.still_off, int))
    tester.assert_(isinstance(obj.button_select_or_activate, int))
    tester.assert_(isinstance(obj.resume, int))
    tester.assert_(isinstance(obj.chapter_menu_call, int))
    tester.assert_(isinstance(obj.angle_menu_call, int))
    tester.assert_(isinstance(obj.audio_menu_call, int))
    tester.assert_(isinstance(obj.subpic_menu_call, int))
    tester.assert_(isinstance(obj.root_menu_call, int))
    tester.assert_(isinstance(obj.title_menu_call, int))
    tester.assert_(isinstance(obj.backward_scan, int))
    tester.assert_(isinstance(obj.forward_scan, int))
    tester.assert_(isinstance(obj.next_pg_search, int))
    tester.assert_(isinstance(obj.prev_or_top_pg_search, int))
    tester.assert_(isinstance(obj.time_or_chapter_search, int))
    tester.assert_(isinstance(obj.go_up, int))
    tester.assert_(isinstance(obj.stop, int))
    tester.assert_(isinstance(obj.title_play, int))
    tester.assert_(isinstance(obj.chapter_search_or_play, int))
    tester.assert_(isinstance(obj.title_or_time_play, int))

def pgc_t(obj, tester):
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.nr_of_programs, int))
    tester.assert_(isinstance(obj.nr_of_cells, int))
    tester.assert_(isinstance(obj.playback_time, ifo_types.dvd_time_t))
    dvd_time_t(obj.playback_time, tester)
    tester.assert_(isinstance(obj.prohibited_ops, ifo_types.user_ops_t))
    user_ops_t(obj.prohibited_ops, tester)
    tester.assert_(isinstance(obj.audio_control, list))
    tester.assertEqual(len(obj.audio_control), 8)
    for elem in obj.audio_control:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.subp_control, list))
    tester.assertEqual(len(obj.subp_control), 32)
    for elem in obj.subp_control:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.next_pgc_nr, int))
    tester.assert_(isinstance(obj.prev_pgc_nr, int))
    tester.assert_(isinstance(obj.goup_pgc_nr, int))
    tester.assert_(isinstance(obj.pg_playback_mode, int))
    tester.assert_(isinstance(obj.still_time, int))
    tester.assert_(isinstance(obj.palette, list))
    tester.assertEqual(len(obj.palette), 16)
    for elem in obj.palette:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.command_tbl_offset, int))
    tester.assert_(isinstance(obj.program_map_offset, int))
    tester.assert_(isinstance(obj.cell_playback_offset, int))
    tester.assert_(isinstance(obj.cell_position_offset, int))
    if obj.command_tbl:
        tester.assert_(isinstance(obj.command_tbl, ifo_types.pgc_command_tbl_t))
        pgc_command_tbl_t(obj.command_tbl, tester)
    tester.assert_(callable(obj.program_map))
    for i in range(obj.nr_of_programs):
        tester.assert_(isinstance(obj.program_map(i), int))
    tester.assert_(callable(obj.cell_playback))
    for i in range(obj.nr_of_cells):
        tester.assert_(isinstance(obj.cell_playback(i), ifo_types.cell_playback_t))
        cell_playback_t(obj.cell_playback(i), tester)
    tester.assert_(callable(obj.cell_position))
    for i in range(obj.nr_of_cells):
        tester.assert_(isinstance(obj.cell_position(i), ifo_types.cell_position_t))
        cell_position_t(obj.cell_position(i), tester)

def pgci_srp_t(obj, tester):
    tester.assert_(isinstance(obj.entry_id, int))
    tester.assert_(isinstance(obj.block_mode, int))
    tester.assert_(isinstance(obj.block_type, int))
    tester.assert_(isinstance(obj.unknown1, int))
    tester.assert_(isinstance(obj.ptl_id_mask, int))
    tester.assert_(isinstance(obj.pgc_start_byte, int))
    tester.assert_(isinstance(obj.pgc, ifo_types.pgc_t))
    pgc_t(obj.pgc, tester)

def pgcit_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_pgci_srp, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.pgci_srp))
    for i in range(obj.nr_of_pgci_srp):
        tester.assert_(isinstance(obj.pgci_srp(i), ifo_types.pgci_srp_t))
        pgci_srp_t(obj.pgci_srp(i), tester)

def pgci_lu_t(obj, tester):
    tester.assert_(isinstance(obj.lang_code, int))
    tester.assert_(isinstance(obj.lang_extension, int))
    tester.assert_(isinstance(obj.exists, int))
    tester.assert_(isinstance(obj.lang_start_byte, int))
    tester.assert_(isinstance(obj.pgcit, ifo_types.pgcit_t))
    pgcit_t(obj.pgcit, tester)

def pgci_ut_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_lus, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.lu))
    for i in range(obj.nr_of_lus):
        tester.assert_(isinstance(obj.lu(i), ifo_types.pgci_lu_t))
        pgci_lu_t(obj.lu(i), tester)

def cell_adr_t(obj, tester):
    tester.assert_(isinstance(obj.vob_id, int))
    tester.assert_(isinstance(obj.cell_id, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.start_sector, int))
    tester.assert_(isinstance(obj.last_sector, int))

def c_adt_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_vobs, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.cell_adr_table))
    for i in range(obj.nr_of_vobs):
        tester.assert_(isinstance(obj.cell_adr_table(i), ifo_types.cell_adr_t))
        cell_adr_t(obj.cell_adr_table(i), tester)

def vobu_admap_t(obj, tester):
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.vobu_start_sectors))
    tester.assert_(isinstance(obj.vobu_start_sectors(0), int))

def vmgi_mat_t(obj, tester):
    tester.assert_(isinstance(obj.vmg_identifier, str))
    tester.assert_(isinstance(obj.vmg_last_sector, int))
    tester.assert_(isinstance(obj.zero_1, list))
    tester.assertEqual(len(obj.zero_1), 12)
    for elem in obj.zero_1:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vmgi_last_sector, int))
    tester.assert_(isinstance(obj.zero_2, int))
    tester.assert_(isinstance(obj.specification_version, int))
    tester.assert_(isinstance(obj.vmg_category, int))
    tester.assert_(isinstance(obj.vmg_nr_of_volumes, int))
    tester.assert_(isinstance(obj.vmg_this_volume_nr, int))
    tester.assert_(isinstance(obj.disc_side, int))
    tester.assert_(isinstance(obj.zero_3, list))
    tester.assertEqual(len(obj.zero_3), 19)
    for elem in obj.zero_3:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vmg_nr_of_title_sets, int))
    tester.assert_(isinstance(obj.provider_identifier, str))
    tester.assert_(isinstance(obj.vmg_pos_code, int))
    tester.assert_(isinstance(obj.zero_4, list))
    tester.assertEqual(len(obj.zero_4), 24)
    for elem in obj.zero_4:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vmgi_last_byte, int))
    tester.assert_(isinstance(obj.first_play_pgc, int))
    tester.assert_(isinstance(obj.zero_5, list))
    tester.assertEqual(len(obj.zero_5), 56)
    for elem in obj.zero_5:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vmgm_vobs, int))
    tester.assert_(isinstance(obj.tt_srpt, int))
    tester.assert_(isinstance(obj.vmgm_pgci_ut, int))
    tester.assert_(isinstance(obj.ptl_mait, int))
    tester.assert_(isinstance(obj.vts_atrt, int))
    tester.assert_(isinstance(obj.txtdt_mgi, int))
    tester.assert_(isinstance(obj.vmgm_c_adt, int))
    tester.assert_(isinstance(obj.vmgm_vobu_admap, int))
    tester.assert_(isinstance(obj.zero_6, list))
    tester.assertEqual(len(obj.zero_6), 32)
    for elem in obj.zero_6:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vmgm_video_attr, ifo_types.video_attr_t))
    video_attr_t(obj.vmgm_video_attr, tester)
    tester.assert_(isinstance(obj.zero_7, int))
    tester.assert_(isinstance(obj.nr_of_vmgm_audio_streams, int))
    if obj.nr_of_vmgm_audio_streams == 1:
        tester.assert_(isinstance(obj.vmgm_audio_attr, ifo_types.audio_attr_t))
        audio_attr_t(obj.vmgm_audio_attr, tester)
    tester.assert_(isinstance(obj.zero_8, list))
    tester.assertEqual(len(obj.zero_8), 7)
    for elem in obj.zero_8:
        tester.assert_(isinstance(elem, ifo_types.audio_attr_t))
    tester.assert_(isinstance(obj.zero_9, list))
    tester.assertEqual(len(obj.zero_9), 17)
    for elem in obj.zero_9:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.nr_of_vmgm_subp_streams, int))
    if obj.nr_of_vmgm_subp_streams == 1:
        tester.assert_(isinstance(obj.vmgm_subp_attr, ifo_types.subp_attr_t))
        subp_attr_t(obj.vmgm_subp_attr, tester)
    tester.assert_(isinstance(obj.zero_10, list))
    tester.assertEqual(len(obj.zero_10), 27)
    for elem in obj.zero_10:
        tester.assert_(isinstance(elem, ifo_types.subp_attr_t))

def playback_type_t(obj, tester):
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.multi_or_random_pgc_title, int))
    tester.assert_(isinstance(obj.jlc_exists_in_cell_cmd, int))
    tester.assert_(isinstance(obj.jlc_exists_in_prepost_cmd, int))
    tester.assert_(isinstance(obj.jlc_exists_in_button_cmd, int))
    tester.assert_(isinstance(obj.jlc_exists_in_tt_dom, int))
    tester.assert_(isinstance(obj.chapter_search_or_play, int))
    tester.assert_(isinstance(obj.title_or_time_play, int))

def title_info_t(obj, tester):
    tester.assert_(isinstance(obj.pb_ty, ifo_types.playback_type_t))
    tester.assert_(isinstance(obj.nr_of_angles, int))
    tester.assert_(isinstance(obj.nr_of_ptts, int))
    tester.assert_(isinstance(obj.parental_id, int))
    tester.assert_(isinstance(obj.title_set_nr, int))
    tester.assert_(isinstance(obj.vts_ttn, int))
    tester.assert_(isinstance(obj.title_set_sector, int))

def tt_srpt_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_srpts, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.title))
    for i in range(obj.nr_of_srpts):
        tester.assert_(isinstance(obj.title(i), ifo_types.title_info_t))
        title_info_t(obj.title(i), tester)

def ptl_mait_country_t(obj, tester):
    tester.assert_(isinstance(obj.country_code, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.pf_ptl_mai_start_byte, int))
    tester.assert_(isinstance(obj.zero_2, int))
    tester.assert_(isinstance(obj.pf_ptl_mai, ifo_types.pf_level_t))
    pf_level_t(obj.pf_ptl_mai, tester)

def ptl_mait_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_countries, int))
    tester.assert_(isinstance(obj.nr_of_vtss, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(isinstance(obj.countries, list))
    tester.assertEqual(len(obj.countries), obj.nr_of_countries)
    for elem in obj.countries:
        tester.assert_(isinstance(elem, ifo_types.ptl_mait_country_t))
        ptl_mait_country_t(elem, tester)

def vts_attributes_t(obj, tester):
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(isinstance(obj.vts_cat, int))
    tester.assert_(isinstance(obj.vtsm_vobs_attr, ifo_types.video_attr_t))
    video_attr_t(obj.vtsm_vobs_attr, tester)
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.nr_of_vtsm_audio_streams, int))
    if obj.nr_of_vtsm_audio_streams == 1:
        tester.assert_(isinstance(obj.vtsm_audio_attr, ifo_types.audio_attr_t))
        audio_attr_t(obj.vtsm_audio_attr, tester)
    tester.assert_(isinstance(obj.zero_2, list))
    tester.assertEqual(len(obj.zero_2), 7)
    for elem in obj.zero_2:
        tester.assert_(isinstance(elem, ifo_types.audio_attr_t))
    tester.assert_(isinstance(obj.zero_3, list))
    tester.assertEqual(len(obj.zero_3), 16)
    for elem in obj.zero_3:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.zero_4, int))
    tester.assert_(isinstance(obj.nr_of_vtsm_subp_streams, int))
    if obj.nr_of_vtsm_subp_streams == 1:
        tester.assert_(isinstance(obj.vtsm_subp_attr, ifo_types.subp_attr_t))
        subp_attr_t(obj.vtsm_subp_attr, tester)
    tester.assert_(isinstance(obj.zero_5, list))
    tester.assertEqual(len(obj.zero_5), 27)
    for elem in obj.zero_5:
        tester.assert_(isinstance(elem, ifo_types.subp_attr_t))
    tester.assert_(isinstance(obj.zero_6, list))
    tester.assertEqual(len(obj.zero_6), 2)
    for elem in obj.zero_6:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vtstt_vobs_video_attr, ifo_types.video_attr_t))
    video_attr_t(obj.vtstt_vobs_video_attr, tester)
    tester.assert_(isinstance(obj.zero_7, int))
    tester.assert_(isinstance(obj.nr_of_vtstt_audio_streams, int))
    tester.assert_(isinstance(obj.vtstt_audio_attr, list))
    tester.assertEqual(len(obj.vtstt_audio_attr), 8)
    for i in range(obj.nr_of_vtstt_audio_streams):
        tester.assert_(isinstance(obj.vtstt_audio_attr[i], ifo_types.audio_attr_t))
        audio_attr_t(obj.vtstt_audio_attr[i], tester)
    tester.assert_(isinstance(obj.zero_8, list))
    tester.assertEqual(len(obj.zero_8), 16)
    for elem in obj.zero_8:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.zero_9, int))
    tester.assert_(isinstance(obj.nr_of_vtstt_subp_streams, int))
    tester.assert_(isinstance(obj.vtstt_subp_attr, list))
    tester.assertEqual(len(obj.vtstt_subp_attr), 32)
    for i in range(obj.nr_of_vtstt_subp_streams):
        tester.assert_(isinstance(obj.vtstt_subp_attr[i], ifo_types.subp_attr_t))
        subp_attr_t(obj.vtstt_subp_attr[i], tester)

def vts_atrt_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_vtss, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.vts))
    for i in range(obj.nr_of_vtss):
        tester.assert_(isinstance(obj.vts(i), ifo_types.vts_attributes_t))
        vts_attributes_t(obj.vts(i), tester)
    tester.assert_(callable(obj.vts_atrt_offsets))
    for i in range(obj.nr_of_vtss):
        tester.assert_(isinstance(obj.vts_atrt_offsets(i), int))

def txtdt_t(obj, tester):
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(isinstance(obj.offsets, list))
    tester.assertEqual(len(obj.offsets), 100)
    for elem in obj.offsets:
        tester.assert_(isinstance(elem, int))

def txtdt_lu_t(obj, tester):
    tester.assert_(isinstance(obj.lang_code, int))
    tester.assert_(isinstance(obj.unknown, int))
    tester.assert_(isinstance(obj.txtdt_start_byte, int))
    tester.assert_(isinstance(obj.txtdt, ifo_types.txtdt_t))
    txtdt_t(obj.txtdt, tester)

def txtdt_mgi_t(obj, tester):
    tester.assert_(isinstance(obj.disc_name, str))
    tester.assert_(isinstance(obj.nr_of_language_units, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(isinstance(obj.lu, list))
    tester.assertEqual(len(obj.lu), obj.nr_of_language_units)
    for elem in obj.lu:
        tester.assert_(isinstance(elem, ifo_types.txtdt_lu_t))
        txtdt_lu_t(elem, tester)

def vtsi_mat_t(obj, tester):
    tester.assert_(isinstance(obj.vts_identifier, str))
    tester.assert_(isinstance(obj.vts_last_sector, int))
    tester.assert_(isinstance(obj.zero_1, list))
    tester.assertEqual(len(obj.zero_1), 12)
    for elem in obj.zero_1:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vtsi_last_sector, int))
    tester.assert_(isinstance(obj.zero_2, int))
    tester.assert_(isinstance(obj.specification_version, int))
    tester.assert_(isinstance(obj.vts_category, int))
    tester.assert_(isinstance(obj.zero_3, int))
    tester.assert_(isinstance(obj.zero_4, int))
    tester.assert_(isinstance(obj.zero_5, int))
    tester.assert_(isinstance(obj.zero_6, list))
    tester.assertEqual(len(obj.zero_6), 19)
    for elem in obj.zero_6:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.zero_7, int))
    tester.assert_(isinstance(obj.zero_8, list))
    tester.assertEqual(len(obj.zero_8), 32)
    for elem in obj.zero_8:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.zero_9, int))
    tester.assert_(isinstance(obj.zero_10, list))
    tester.assertEqual(len(obj.zero_10), 24)
    for elem in obj.zero_10:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vtsi_last_byte, int))
    tester.assert_(isinstance(obj.zero_11, int))
    tester.assert_(isinstance(obj.zero_12, list))
    tester.assertEqual(len(obj.zero_12), 56)
    for elem in obj.zero_12:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vtsm_vobs, int))
    tester.assert_(isinstance(obj.vtstt_vobs, int))
    tester.assert_(isinstance(obj.vts_ptt_srpt, int))
    tester.assert_(isinstance(obj.vts_pgcit, int))
    tester.assert_(isinstance(obj.vtsm_pgci_ut, int))
    tester.assert_(isinstance(obj.vts_tmapt, int))
    tester.assert_(isinstance(obj.vtsm_c_adt, int))
    tester.assert_(isinstance(obj.vtsm_vobu_admap, int))
    tester.assert_(isinstance(obj.vts_c_adt, int))
    tester.assert_(isinstance(obj.vts_vobu_admap, int))
    tester.assert_(isinstance(obj.zero_13, list))
    tester.assertEqual(len(obj.zero_13), 24)
    for elem in obj.zero_13:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vtsm_video_attr, ifo_types.video_attr_t))
    video_attr_t(obj.vtsm_video_attr, tester)
    tester.assert_(isinstance(obj.zero_14, int))
    tester.assert_(isinstance(obj.nr_of_vtsm_audio_streams, int))
    if obj.nr_of_vtsm_audio_streams == 1:
        tester.assert_(isinstance(obj.vtsm_audio_attr, ifo_types.audio_attr_t))
        audio_attr_t(obj.vtsm_audio_attr, tester)
    tester.assert_(isinstance(obj.zero_15, list))
    tester.assertEqual(len(obj.zero_15), 7)
    for elem in obj.zero_15:
        tester.assert_(isinstance(elem, ifo_types.audio_attr_t))
    tester.assert_(isinstance(obj.zero_16, list))
    tester.assertEqual(len(obj.zero_16), 17)
    for elem in obj.zero_16:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.nr_of_vtsm_subp_streams, int))
    if obj.nr_of_vtsm_subp_streams == 1:
        tester.assert_(isinstance(obj.vtsm_subp_attr, ifo_types.subp_attr_t))
        subp_attr_t(obj.vtsm_subp_attr, tester)
    tester.assert_(isinstance(obj.zero_17, list))
    tester.assertEqual(len(obj.zero_17), 27)
    for elem in obj.zero_17:
        tester.assert_(isinstance(elem, ifo_types.subp_attr_t))
    tester.assert_(isinstance(obj.zero_18, list))
    tester.assertEqual(len(obj.zero_18), 2)
    for elem in obj.zero_18:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.vts_video_attr, ifo_types.video_attr_t))
    video_attr_t(obj.vts_video_attr, tester)
    tester.assert_(isinstance(obj.zero_19, int))
    tester.assert_(isinstance(obj.nr_of_vts_audio_streams, int))
    tester.assert_(isinstance(obj.vts_audio_attr, list))
    tester.assertEqual(len(obj.vts_audio_attr), 8)
    for i in range(obj.nr_of_vts_audio_streams):
        tester.assert_(isinstance(obj.vts_audio_attr[i], ifo_types.audio_attr_t))
        audio_attr_t(obj.vts_audio_attr[i], tester)
    tester.assert_(isinstance(obj.zero_20, list))
    tester.assertEqual(len(obj.zero_20), 17)
    for elem in obj.zero_20:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.nr_of_vts_subp_streams, int))
    tester.assert_(isinstance(obj.vts_subp_attr, list))
    tester.assertEqual(len(obj.vts_subp_attr), 32)
    for i in range(obj.nr_of_vts_subp_streams):
        tester.assert_(isinstance(obj.vts_subp_attr[i], ifo_types.subp_attr_t))
        subp_attr_t(obj.vts_subp_attr[i], tester)
    tester.assert_(isinstance(obj.zero_21, int))
    tester.assert_(isinstance(obj.vts_mu_audio_attr, list))
    tester.assertEqual(len(obj.vts_mu_audio_attr), 8)
    for elem in obj.vts_mu_audio_attr:
        tester.assert_(isinstance(elem, ifo_types.multichannel_ext_t))
        multichannel_ext_t(elem, tester)

def ptt_info_t(obj, tester):
    tester.assert_(isinstance(obj.pgcn, int))
    tester.assert_(isinstance(obj.pgn, int))

def ttu_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_ptts, int))
    tester.assert_(callable(obj.ptt))
    for i in range(obj.nr_of_ptts):
        tester.assert_(isinstance(obj.ptt(i), ifo_types.ptt_info_t))
        ptt_info_t(obj.ptt(i), tester)

def vts_ptt_srpt_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_srpts, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.title))
    for i in range(obj.nr_of_srpts):
        tester.assert_(isinstance(obj.title(i), ifo_types.ttu_t))
        ttu_t(obj.title(i), tester)
    tester.assert_(callable(obj.ttu_offset))
    for i in range(obj.nr_of_srpts):
        tester.assert_(isinstance(obj.ttu_offset(i), int))

def vts_tmap_t(obj, tester):
    tester.assert_(isinstance(obj.tmu, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.nr_of_entries, int))
    tester.assert_(callable(obj.map_ent))
    for i in range(obj.nr_of_entries):
        tester.assert_(isinstance(obj.map_ent(i), int))

def vts_tmapt_t(obj, tester):
    tester.assert_(isinstance(obj.nr_of_tmaps, int))
    tester.assert_(isinstance(obj.zero_1, int))
    tester.assert_(isinstance(obj.last_byte, int))
    tester.assert_(callable(obj.tmap))
    for i in range(obj.nr_of_tmaps):
        tester.assert_(isinstance(obj.tmap(i), ifo_types.vts_tmap_t))
        vts_tmap_t(obj.tmap(i), tester)
    tester.assert_(callable(obj.tmap_offset))
    for i in range(obj.nr_of_tmaps):
        tester.assert_(isinstance(obj.tmap_offset(i), int))

def ifo_handle_t(obj, tester):
    tester.assertNotEqual(obj.file, None)
    if obj.vmgi_mat:
        tester.assert_(isinstance(obj.vmgi_mat, ifo_types.vmgi_mat_t))
        vmgi_mat_t(obj.vmgi_mat, tester)
    if obj.tt_srpt:
        tester.assert_(isinstance(obj.tt_srpt, ifo_types.tt_srpt_t))
        tt_srpt_t(obj.tt_srpt, tester)
    if obj.first_play_pgc:
        tester.assert_(isinstance(obj.first_play_pgc, ifo_types.pgc_t))
        pgc_t(obj.first_play_pgc, tester)
    if obj.ptl_mait:
        tester.assert_(isinstance(obj.ptl_mait, ifo_types.ptl_mait_t))
        ptl_mait_t(obj.ptl_mait, tester)
    if obj.vts_atrt:
        tester.assert_(isinstance(obj.vts_atrt, ifo_types.vts_atrt_t))
        vts_atrt_t(obj.vts_atrt, tester)
    if obj.txtdt_mgi:
        tester.assert_(isinstance(obj.txtdt_mgi, ifo_types.txtdt_mgi_t))
        txtdt_mgi_t(obj.txtdt_mgi, tester)
    if obj.pgci_ut:
        tester.assert_(isinstance(obj.pgci_ut, ifo_types.pgci_ut_t))
        pgci_ut_t(obj.pgci_ut, tester)
    if obj.menu_c_adt:
        tester.assert_(isinstance(obj.menu_c_adt, ifo_types.c_adt_t))
        c_adt_t(obj.menu_c_adt, tester)
    if obj.menu_vobu_admap:
        tester.assert_(isinstance(obj.menu_vobu_admap, ifo_types.vobu_admap_t))
        vobu_admap_t(obj.menu_vobu_admap, tester)
    if obj.vtsi_mat:
        tester.assert_(isinstance(obj.vtsi_mat, ifo_types.vtsi_mat_t))
        vtsi_mat_t(obj.vtsi_mat, tester)
    if obj.vts_ptt_srpt:
        tester.assert_(isinstance(obj.vts_ptt_srpt, ifo_types.vts_ptt_srpt_t))
        vts_ptt_srpt_t(obj.vts_ptt_srpt, tester)
    if obj.vts_pgcit:
        tester.assert_(isinstance(obj.vts_pgcit, ifo_types.pgcit_t))
        pgcit_t(obj.vts_pgcit, tester)
    if obj.vts_tmapt:
        tester.assert_(isinstance(obj.vts_tmapt, ifo_types.vts_tmapt_t))
        vts_tmapt_t(obj.vts_tmapt, tester)
    if obj.vts_c_adt:
        tester.assert_(isinstance(obj.vts_c_adt, ifo_types.c_adt_t))
        c_adt_t(obj.vts_c_adt, tester)
    if obj.vts_vobu_admap:
        tester.assert_(isinstance(obj.vts_vobu_admap, ifo_types.vobu_admap_t))
        vobu_admap_t(obj.vts_vobu_admap, tester)


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

