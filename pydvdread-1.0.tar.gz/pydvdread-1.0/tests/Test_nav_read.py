#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import nav_read, dvd_reader, nav_types


class Test1(unittest.TestCase):
    
    def setUp(self):
        dvd = dvd_reader.DVDOpen(DVDPATH)
        vob = dvd_reader.DVDOpenFile(dvd, 1, dvd_reader.DVD_READ_TITLE_VOBS)
        self.block = dvd_reader.DVDReadBlocks(vob, 0, 1)
        dvd_reader.DVDCloseFile(vob)
        dvd_reader.DVDClose(dvd)
    
    def test_navRead_PCI(self):
        pci = nav_read.navRead_PCI(self.block);
        self.assert_(isinstance(pci, nav_types.pci_t))

    def test_navRead_DSI(self):
        dsi = nav_read.navRead_DSI(self.block);
        self.assert_(isinstance(dsi, nav_types.dsi_t))


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

