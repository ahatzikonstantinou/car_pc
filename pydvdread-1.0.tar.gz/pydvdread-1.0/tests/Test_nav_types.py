#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import nav_types, dvd_reader, nav_read, ifo_types
from Test_ifo_types import user_ops_t, dvd_time_t, vm_cmd_t


class Test1(unittest.TestCase):
    
    def setUp(self):
        dvd = dvd_reader.DVDOpen(DVDPATH)
        vob = dvd_reader.DVDOpenFile(dvd, 1, dvd_reader.DVD_READ_TITLE_VOBS)
        block = dvd_reader.DVDReadBlocks(vob, 0, 1)
        self.pci = nav_read.navRead_PCI(block)
        self.dsi = nav_read.navRead_DSI(block)
        dvd_reader.DVDCloseFile(vob)
        dvd_reader.DVDClose(dvd)
    
    def testPCI(self):
        pci_t(self.pci, self)

    def testDSI(self):
        dsi_t(self.dsi, self)

class Test2(unittest.TestCase):
    
    def testConstants(self):
        self.assertEqual(nav_types.PCI_BYTES, 0x3d4)
        self.assertEqual(nav_types.DSI_BYTES, 0x3fa)
        self.assertEqual(nav_types.PS2_PCI_SUBSTREAM_ID, 0x00)
        self.assertEqual(nav_types.PS2_DSI_SUBSTREAM_ID, 0x01)
        self.assertEqual(nav_types.DSI_START_BYTE, 1031)
        self.assertEqual(nav_types.SRI_END_OF_CELL, 0x3fffffff)


# Helper functions

def pci_gi_t(obj, tester):
    tester.assert_(isinstance(obj.nv_pck_lbn, int))
    tester.assert_(isinstance(obj.vobu_cat, int))
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.vobu_uop_ctl, ifo_types.user_ops_t))
    user_ops_t(obj.vobu_uop_ctl, tester)
    tester.assert_(isinstance(obj.vobu_s_ptm, int))
    tester.assert_(isinstance(obj.vobu_e_ptm, int))
    tester.assert_(isinstance(obj.vobu_se_e_ptm, int))
    tester.assert_(isinstance(obj.e_eltm, ifo_types.dvd_time_t))
    dvd_time_t(obj.e_eltm, tester)
    tester.assert_(isinstance(obj.vobu_isrc, str))

def nsml_agli_t(obj, tester):
    tester.assert_(isinstance(obj.nsml_agl_dsta, list))
    tester.assertEqual(len(obj.nsml_agl_dsta), 9)
    for elem in obj.nsml_agl_dsta:
        tester.assert_(isinstance(elem, int))

def hl_gi_t(obj, tester):
    tester.assert_(isinstance(obj.hli_ss, int))
    tester.assert_(isinstance(obj.hli_s_ptm, int))
    tester.assert_(isinstance(obj.hli_e_ptm, int))
    tester.assert_(isinstance(obj.btn_se_e_ptm, int))
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.btngr_ns, int))
    tester.assert_(isinstance(obj.zero2, int))
    tester.assert_(isinstance(obj.btngr1_dsp_ty, int))
    tester.assert_(isinstance(obj.zero3, int))
    tester.assert_(isinstance(obj.btngr2_dsp_ty, int))
    tester.assert_(isinstance(obj.zero4, int))
    tester.assert_(isinstance(obj.btngr3_dsp_ty, int))
    tester.assert_(isinstance(obj.btn_ofn, int))
    tester.assert_(isinstance(obj.btn_ns, int))
    tester.assert_(isinstance(obj.nsl_btn_ns, int))
    tester.assert_(isinstance(obj.zero5, int))
    tester.assert_(isinstance(obj.fosl_btnn, int))
    tester.assert_(isinstance(obj.foac_btnn, int))

def btn_colit_t(obj, tester):
    tester.assert_(isinstance(obj.btn_coli, list))
    tester.assertEqual(len(obj.btn_coli), 3)
    for elem in obj.btn_coli:
        tester.assert_(isinstance(elem, list))
        tester.assertEqual(len(elem), 2)
        for elem2 in elem:
            tester.assert_(isinstance(elem2, int))

def btni_t(obj, tester):
    tester.assert_(isinstance(obj.btn_coln, int))
    tester.assert_(isinstance(obj.x_start, int))
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.x_end, int))
    tester.assert_(isinstance(obj.zero3, int))
    tester.assert_(isinstance(obj.up, int))
    tester.assert_(isinstance(obj.auto_action_mode, int))
    tester.assert_(isinstance(obj.y_start, int))
    tester.assert_(isinstance(obj.zero2, int))
    tester.assert_(isinstance(obj.y_end, int))
    tester.assert_(isinstance(obj.zero4, int))
    tester.assert_(isinstance(obj.down, int))
    tester.assert_(isinstance(obj.zero5, int))
    tester.assert_(isinstance(obj.left, int))
    tester.assert_(isinstance(obj.zero6, int))
    tester.assert_(isinstance(obj.right, int))
    tester.assert_(isinstance(obj.cmd, ifo_types.vm_cmd_t))
    vm_cmd_t(obj.cmd, tester)

def hli_t(obj, tester):
    tester.assert_(isinstance(obj.hl_gi, nav_types.hl_gi_t))
    hl_gi_t(obj.hl_gi, tester)
    tester.assert_(isinstance(obj.btn_colit, nav_types.btn_colit_t))
    btn_colit_t(obj.btn_colit, tester)
    tester.assert_(isinstance(obj.btnit, list))
    tester.assertEqual(len(obj.btnit), 36)
    for elem in obj.btnit:
        tester.assert_(isinstance(elem, nav_types.btni_t))
        btni_t(elem, tester)

def pci_t(obj, tester):
    tester.assert_(isinstance(obj.pci_gi, nav_types.pci_gi_t))
    pci_gi_t(obj.pci_gi, tester)
    tester.assert_(isinstance(obj.nsml_agli, nav_types.nsml_agli_t))
    nsml_agli_t(obj.nsml_agli, tester)
    tester.assert_(isinstance(obj.hli, nav_types.hli_t))
    hli_t(obj.hli, tester)
    tester.assert_(isinstance(obj.zero1, list))
    tester.assertEqual(len(obj.zero1), 189)
    for elem in obj.zero1:
        tester.assert_(isinstance(elem, int))

def dsi_gi_t(obj, tester):
    tester.assert_(isinstance(obj.nv_pck_scr, int))
    tester.assert_(isinstance(obj.nv_pck_lbn, int))
    tester.assert_(isinstance(obj.vobu_ea, int))
    tester.assert_(isinstance(obj.vobu_1stref_ea, int))
    tester.assert_(isinstance(obj.vobu_2ndref_ea, int))
    tester.assert_(isinstance(obj.vobu_3rdref_ea, int))
    tester.assert_(isinstance(obj.vobu_vob_idn, int))
    tester.assert_(isinstance(obj.zero1, int))
    tester.assert_(isinstance(obj.vobu_c_idn, int))
    tester.assert_(isinstance(obj.c_eltm, ifo_types.dvd_time_t))
    dvd_time_t(obj.c_eltm, tester)

def sml_pbi_t(obj, tester):
    tester.assert_(isinstance(obj.category, int))
    tester.assert_(isinstance(obj.ilvu_ea, int))
    tester.assert_(isinstance(obj.ilvu_sa, int))
    tester.assert_(isinstance(obj.size, int))
    tester.assert_(isinstance(obj.vob_v_s_s_ptm, int))
    tester.assert_(isinstance(obj.vob_v_e_e_ptm, int))
    for i in range(8):
        tester.assert_(isinstance(obj.vob_a[i].stp_ptm1, int))
        tester.assert_(isinstance(obj.vob_a[i].stp_ptm2, int))
        tester.assert_(isinstance(obj.vob_a[i].gap_len1, int))
        tester.assert_(isinstance(obj.vob_a[i].gap_len2, int))

def sml_agl_data_t(obj, tester):
    tester.assert_(isinstance(obj.address, int))
    tester.assert_(isinstance(obj.size, int))

def sml_agli_t(obj, tester):
    tester.assert_(isinstance(obj.data, list))
    tester.assertEqual(len(obj.data), 9)
    for elem in obj.data:
        tester.assert_(isinstance(elem, nav_types.sml_agl_data_t))
        sml_agl_data_t(elem, tester)

def vobu_sri_t(obj, tester):
    tester.assert_(isinstance(obj.next_video, int))
    tester.assert_(isinstance(obj.fwda, list))
    tester.assertEqual(len(obj.fwda), 19)
    for elem in obj.fwda:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.next_vobu, int))
    tester.assert_(isinstance(obj.prev_vobu, int))
    tester.assert_(isinstance(obj.bwda, list))
    tester.assertEqual(len(obj.bwda), 19)
    for elem in obj.bwda:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.prev_video, int))

def synci_t(obj, tester):
    tester.assert_(isinstance(obj.a_synca, list))
    tester.assertEqual(len(obj.a_synca), 8)
    for elem in obj.a_synca:
        tester.assert_(isinstance(elem, int))
    tester.assert_(isinstance(obj.sp_synca, list))
    tester.assertEqual(len(obj.sp_synca), 32)
    for elem in obj.sp_synca:
        tester.assert_(isinstance(elem, int))

def dsi_t(obj, tester):
    tester.assert_(isinstance(obj.dsi_gi, nav_types.dsi_gi_t))
    dsi_gi_t(obj.dsi_gi, tester)
    tester.assert_(isinstance(obj.sml_pbi, nav_types.sml_pbi_t))
    sml_pbi_t(obj.sml_pbi, tester)
    tester.assert_(isinstance(obj.sml_agli, nav_types.sml_agli_t))
    sml_agli_t(obj.sml_agli, tester)
    tester.assert_(isinstance(obj.vobu_sri, nav_types.vobu_sri_t))
    vobu_sri_t(obj.vobu_sri, tester)
    tester.assert_(isinstance(obj.synci, nav_types.synci_t))
    synci_t(obj.synci, tester)
    tester.assert_(isinstance(obj.zero1, list))
    tester.assertEqual(len(obj.zero1), 471)
    for elem in obj.zero1:
        tester.assert_(isinstance(elem, int))


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

