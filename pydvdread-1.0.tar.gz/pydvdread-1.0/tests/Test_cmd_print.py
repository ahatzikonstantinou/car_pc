#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import cmd_print, ifo_read, dvd_reader


class Test1(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo0 = ifo_read.ifoOpen(self.dvd, 0)
        self.ifo = ifo_read.ifoOpen(self.dvd, 1)
        self.command = pgc_t(self.ifo0.first_play_pgc)
        if self.command: return
        self.command = pgci_ut_t(self.ifo0.pgci_ut)
        if self.command: return
        self.command = pgci_ut_t(self.ifo.pgci_ut)
        if self.command: return
        self.command = pgcit_t(self.ifo.vts_pgcit)
        if self.command: return
        raise Exception('No commands found on DVD!')
    
    def tearDown(self):
        ifo_read.ifoClose(self.ifo0)
        ifo_read.ifoClose(self.ifo)
        dvd_reader.DVDClose(self.dvd)
    
    def test_cmdPrint_mnemonic(self):
        cmd_print.cmdPrint_mnemonic(self.command)
    
    def test_cmdPrint_CMD(self):
        cmd_print.cmdPrint_CMD(0, self.command)


# Helper functions

def pgc_command_tbl_t(obj):
    if obj.nr_of_pre > 0:
        return obj.pre_cmds(0)
    if obj.nr_of_post > 0:
        return obj.post_cmds(0)
    if obj.nr_of_cell > 0:
        return obj.cell_cmds(0)
    return None

def pgc_t(obj):
    return pgc_command_tbl_t(obj.command_tbl)

def pgci_srp_t(obj):
    return pgc_t(obj.pgc)

def pgcit_t(obj):
    if not obj.nr_of_pgci_srp > 0:
        return None
    for elem in obj.pgci_srp:
        ret = pgci_srp_t(elem)
        if ret: return ret
    return None

def pgci_lu_t(obj):
    return pgcit_t(obj.pgcit)

def pgci_ut_t(obj):
    if not obj.nr_of_lus > 0:
        return None
    for elem in obj.lu:
        ret = pgci_lu_t(elem)
        if ret: return ret
    return None


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

