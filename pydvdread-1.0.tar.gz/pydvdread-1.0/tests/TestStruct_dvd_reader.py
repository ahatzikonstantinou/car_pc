#!/usr/bin/env python
# -*- coding: utf-8 -*-

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()


import unittest
from dvdread import dvd_reader


class Test1(unittest.TestCase):
    
    def test_dvd_stat_t(self):
        obj = dvd_reader.dvd_stat_t()
        obj.size = obj.nr_parts = 1
        self.assertEqual(obj.size, 1)
        self.assertEqual(obj.nr_parts, 1)
        obj.set_parts_size(0, 1)
        self.assertEqual(obj.parts_size[0], 1)
        obj.parts_size = range(9)
        self.assertEqual(obj.parts_size, range(9))


# Run the tests
if __name__ == '__main__':
    unittest.main()




