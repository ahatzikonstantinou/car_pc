#!/usr/bin/env python

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()

# Default DVD path (if no argument is passed on the command line)
DVDPATH='/dev/dvd'


import unittest
from dvdread import ifo_read, dvd_reader, ifo_types


class Test1(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo = None
    
    def tearDown(self):
        if self.ifo:
            ifo_read.ifoClose(self.ifo)
        dvd_reader.DVDClose(self.dvd)
    
    def test_ifoOpen(self):
        self.ifo = ifo_read.ifoOpen(self.dvd, 0)
        self.assert_(isinstance(self.ifo, ifo_types.ifo_handle_t))

    def test_ifoOpenVMGI(self):
        self.ifo = ifo_read.ifoOpenVMGI(self.dvd)
        self.assert_(isinstance(self.ifo, ifo_types.ifo_handle_t))

    def test_ifoOpenVTSI(self):
        self.ifo = ifo_read.ifoOpenVTSI(self.dvd, 1)
        self.assert_(isinstance(self.ifo, ifo_types.ifo_handle_t))

class Test2(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo = ifo_read.ifoOpen(self.dvd, 0)
    
    def tearDown(self):
        dvd_reader.DVDClose(self.dvd)
    
    def test_ifoClose(self):
        ifo_read.ifoClose(self.ifo)

class Test3(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo0 = ifo_read.ifoOpen(self.dvd, 0)
        self.ifo = ifo_read.ifoOpen(self.dvd, 1)
    
    def tearDown(self):
        ifo_read.ifoClose(self.ifo)
        ifo_read.ifoClose(self.ifo0)
        dvd_reader.DVDClose(self.dvd)

    def test_ifoRead_PTL_MAIT(self):
        ret = ifo_read.ifoRead_PTL_MAIT(self.ifo0)
        self.assertEqual(ret, 1)

    def test_ifoRead_VTS_ATRT(self):
        ret = ifo_read.ifoRead_VTS_ATRT(self.ifo0)
        self.assertEqual(ret, 1)

    def test_ifoRead_TT_SRPT(self):
        ret = ifo_read.ifoRead_TT_SRPT(self.ifo0)
        self.assertEqual(ret, 1)

    def test_ifoRead_VTS_PTT_SRPT(self):
        ret = ifo_read.ifoRead_VTS_PTT_SRPT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_FP_PGC(self):
        ret = ifo_read.ifoRead_FP_PGC(self.ifo0)
        self.assertEqual(ret, 1)

    def test_ifoRead_PGCIT(self):
        ret = ifo_read.ifoRead_PGCIT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_PGCI_UT(self):
        ret = ifo_read.ifoRead_PGCI_UT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_VTS_TMAPT(self):
        ret = ifo_read.ifoRead_VTS_TMAPT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_C_ADT(self):
        ret = ifo_read.ifoRead_C_ADT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_TITLE_C_ADT(self):
        ret = ifo_read.ifoRead_TITLE_C_ADT(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_VOBU_ADMAP(self):
        ret = ifo_read.ifoRead_VOBU_ADMAP(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_TITLE_VOBU_ADMAP(self):
        ret = ifo_read.ifoRead_TITLE_VOBU_ADMAP(self.ifo)
        self.assertEqual(ret, 1)

    def test_ifoRead_TXTDT_MGI(self):
        ret = ifo_read.ifoRead_TXTDT_MGI(self.ifo0)
        self.assertEqual(ret, 1)

class Test4(unittest.TestCase):
    
    def setUp(self):
        self.dvd = dvd_reader.DVDOpen(DVDPATH)
        self.ifo = ifo_read.ifoOpen(self.dvd, 0)
    
    def tearDown(self):
        ifo_read.ifoClose(self.ifo)
        dvd_reader.DVDClose(self.dvd)

    def test_ifoFree_PTL_MAIT(self):
        ifo_read.ifoFree_PTL_MAIT(self.ifo)

    def test_ifoFree_VTS_ATRT(self):
        ifo_read.ifoFree_VTS_ATRT(self.ifo)

    def test_ifoFree_TT_SRPT(self):
        ifo_read.ifoFree_TT_SRPT(self.ifo)

    def test_ifoFree_VTS_PTT_SRPT(self):
        ifo_read.ifoFree_VTS_PTT_SRPT(self.ifo)

    def test_ifoFree_FP_PGC(self):
        ifo_read.ifoFree_FP_PGC(self.ifo)

    def test_ifoFree_PGCIT(self):
        ifo_read.ifoFree_PGCIT(self.ifo)

    def test_ifoFree_PGCI_UT(self):
        ifo_read.ifoFree_PGCI_UT(self.ifo)

    def test_ifoFree_VTS_TMAPT(self):
        ifo_read.ifoFree_VTS_TMAPT(self.ifo)

    def test_ifoFree_C_ADT(self):
        ifo_read.ifoFree_C_ADT(self.ifo)

    def test_ifoFree_TITLE_C_ADT(self):
        ifo_read.ifoFree_TITLE_C_ADT(self.ifo)

    def test_ifoFree_VOBU_ADMAP(self):
        ifo_read.ifoFree_VOBU_ADMAP(self.ifo)

    def test_ifoFree_TITLE_VOBU_ADMAP(self):
        ifo_read.ifoFree_TITLE_VOBU_ADMAP(self.ifo)

    def test_ifoFree_TXTDT_MGI(self):
        ifo_read.ifoFree_TXTDT_MGI(self.ifo)


# Run the tests
if __name__ == '__main__':
    if len(sys.argv) > 1: DVDPATH = sys.argv[1]
    unittest.main()

