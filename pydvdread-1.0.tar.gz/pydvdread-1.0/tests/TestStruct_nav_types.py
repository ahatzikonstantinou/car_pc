#!/usr/bin/env python
# -*- coding: utf-8 -*-

## Copyright (C) 2007 by Rui Dias <ruijdias@users.sourceforge.net>
##
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or (at
## your option) any later version.
##
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import sys, os


# Add the development path to the search path
def devpath():
    if __name__ != '__main__': return
    path = os.getcwd()
    path = os.path.split(path)[0]
    path = os.path.join(path, 'src')
    sys.path.append(path)

# Comment this line if you want to test an already installed version of pydvdread
devpath()


import unittest
from dvdread import nav_types, ifo_types


class Test1(unittest.TestCase):
    
    def test_pci_gi_t(self):
        obj = nav_types.pci_gi_t()
        obj.nv_pck_lbn = obj.vobu_cat = obj.zero1 = 1
        self.assertEqual(obj.nv_pck_lbn, 1)
        self.assertEqual(obj.vobu_cat, 1)
        self.assertEqual(obj.zero1, 1)
        temp = ifo_types.user_ops_t()
        temp.zero = 1
        obj.vobu_uop_ctl.zero = 0
        obj.vobu_uop_ctl = temp
        self.assertEqual(obj.vobu_uop_ctl.zero, 1)
        obj.vobu_s_ptm = obj.vobu_e_ptm = obj.vobu_se_e_ptm = 1
        self.assertEqual(obj.vobu_s_ptm, 1)
        self.assertEqual(obj.vobu_e_ptm, 1)
        self.assertEqual(obj.vobu_se_e_ptm, 1)
        temp = ifo_types.dvd_time_t()
        temp.hour = 1
        obj.e_eltm.hour = 0
        obj.e_eltm = temp
        self.assertEqual(obj.e_eltm.hour, 1)
        obj.vobu_isrc = 'abc'
        self.assertEqual(obj.vobu_isrc, 'abc')

    def test_nsml_agli_t(self):
        obj = nav_types.nsml_agli_t()
        obj.set_nsml_agl_dsta(0,1)
        self.assertEqual(obj.nsml_agl_dsta[0], 1)
        obj.nsml_agl_dsta = range(9)
        self.assertEqual(obj.nsml_agl_dsta, range(9))

    def test_hl_gi_t(self):
        obj = nav_types.hl_gi_t()
        obj.hli_ss = obj.hli_s_ptm = obj.hli_e_ptm = obj.btn_se_e_ptm = 1
        self.assertEqual(obj.hli_ss, 1)
        self.assertEqual(obj.hli_s_ptm, 1)
        self.assertEqual(obj.hli_e_ptm, 1)
        self.assertEqual(obj.btn_se_e_ptm, 1)
        obj.zero1 = obj.btngr_ns = obj.zero2 = obj.btngr1_dsp_ty = 1
        obj.zero3 = obj.btngr2_dsp_ty = obj.zero4 = obj.btngr3_dsp_ty = 1
        self.assertEqual(obj.zero1, 1)
        self.assertEqual(obj.btngr_ns, 1)
        self.assertEqual(obj.zero2, 1)
        self.assertEqual(obj.btngr1_dsp_ty, 1)
        self.assertEqual(obj.zero3, 1)
        self.assertEqual(obj.btngr2_dsp_ty, 1)
        self.assertEqual(obj.zero4, 1)
        self.assertEqual(obj.btngr3_dsp_ty, 1)
        obj.btn_ofn = obj.btn_ns = obj.nsl_btn_ns = 1
        obj.zero5 = obj.fosl_btnn = obj.foac_btnn = 1
        self.assertEqual(obj.btn_ofn, 1)
        self.assertEqual(obj.btn_ns, 1)
        self.assertEqual(obj.nsl_btn_ns, 1)
        self.assertEqual(obj.zero5, 1)
        self.assertEqual(obj.fosl_btnn, 1)
        self.assertEqual(obj.foac_btnn, 1)

    def test_btn_colit_t(self):
        obj = nav_types.btn_colit_t()
        obj.set_btn_coli(0,0,1)
        self.assertEqual(obj.btn_coli[0][0], 1)
        temp = [range(2), range(2), range(2)]
        obj.btn_coli = temp
        self.assertEqual(obj.btn_coli, temp)

    def test_btni_t(self):
        obj = nav_types.btni_t()
        obj.btn_coln = obj.x_start = obj.zero1 = obj.x_end = 1
        self.assertEqual(obj.btn_coln, 1)
        self.assertEqual(obj.x_start, 1)
        self.assertEqual(obj.zero1, 1)
        self.assertEqual(obj.x_end, 1)
        obj.zero3 = obj.up = obj.auto_action_mode = obj.y_start = 1
        self.assertEqual(obj.zero3, 1)
        self.assertEqual(obj.up, 1)
        self.assertEqual(obj.auto_action_mode, 1)
        self.assertEqual(obj.y_start, 1)
        obj.zero2 = obj.y_end = obj.zero4 = obj.down = 1
        self.assertEqual(obj.zero2, 1)
        self.assertEqual(obj.y_end, 1)
        self.assertEqual(obj.zero4, 1)
        self.assertEqual(obj.down, 1)
        obj.zero5 = obj.left = obj.zero6 = obj.right = 1
        self.assertEqual(obj.zero5, 1)
        self.assertEqual(obj.left, 1)
        self.assertEqual(obj.zero6, 1)
        self.assertEqual(obj.right, 1)
        temp = ifo_types.vm_cmd_t()
        temp.set_bytes(0,1)
        obj.cmd.set_bytes(0,0)
        obj.cmd = temp
        self.assertEqual(obj.cmd.bytes[0], 1)

    def test_hli_t(self):
        obj = nav_types.hli_t()
        temp = nav_types.hl_gi_t()
        temp.hli_ss = 1
        obj.hl_gi.hli_ss = 0
        obj.hl_gi = temp
        self.assertEqual(obj.hl_gi.hli_ss, 1)
        temp = nav_types.btn_colit_t()
        temp.set_btn_coli(0,0,1)
        obj.btn_colit.set_btn_coli(0,0,0)
        obj.btn_colit = temp
        self.assertEqual(obj.btn_colit.btn_coli[0][0], 1)
        temp = nav_types.btni_t()
        temp.x_start = 1
        obj.btnit[0].x_start = 0
        obj.set_btnit(0, temp)
        self.assertEqual(obj.btnit[0].x_start, 1)
        temp = []
        for i in range(36):
            temp.append(nav_types.btni_t())
            temp[i].x_start = i
        obj.btnit = temp
        for i in range(36):
            self.assertEqual(obj.btnit[i].x_start, i)

    def test_pci_t(self):
        obj = nav_types.pci_t()
        temp = nav_types.pci_gi_t()
        temp.vobu_cat = 1
        obj.pci_gi.vobu_cat = 0
        obj.pci_gi = temp
        self.assertEqual(obj.pci_gi.vobu_cat, 1)
        temp = nav_types.nsml_agli_t()
        temp.set_nsml_agl_dsta(0,1)
        obj.nsml_agli.set_nsml_agl_dsta(0,0)
        obj.nsml_agli = temp
        self.assertEqual(obj.nsml_agli.nsml_agl_dsta[0], 1)
        obj.hli = nav_types.hli_t()
        obj.set_zero1(0, 1)
        self.assertEqual(obj.zero1[0], 1)
        obj.zero1 = range(189)
        self.assertEqual(obj.zero1, range(189))

    def test_dsi_gi_t(self):
        obj = nav_types.dsi_gi_t()
        obj.nv_pck_scr = obj.nv_pck_lbn = obj.vobu_ea = 1
        self.assertEqual(obj.nv_pck_scr, 1)
        self.assertEqual(obj.nv_pck_lbn, 1)
        self.assertEqual(obj.vobu_ea, 1)
        obj.vobu_1stref_ea = obj.vobu_2ndref_ea = obj.vobu_3rdref_ea = 1
        self.assertEqual(obj.vobu_1stref_ea, 1)
        self.assertEqual(obj.vobu_2ndref_ea, 1)
        self.assertEqual(obj.vobu_3rdref_ea, 1)
        obj.vobu_vob_idn = obj.zero1 = obj.vobu_c_idn = 1
        self.assertEqual(obj.vobu_vob_idn, 1)
        self.assertEqual(obj.zero1, 1)
        self.assertEqual(obj.vobu_c_idn, 1)
        temp = ifo_types.dvd_time_t()
        temp.hour = 1
        obj.c_eltm.hour = 0
        obj.c_eltm = temp
        self.assertEqual(obj.c_eltm.hour, 1)

    def test_sml_pbi_t(self):
        obj = nav_types.sml_pbi_t()
        obj.category = obj.ilvu_ea = obj.ilvu_sa = 1
        self.assertEqual(obj.category, 1)
        self.assertEqual(obj.ilvu_ea, 1)
        self.assertEqual(obj.ilvu_sa, 1)
        obj.size = obj.vob_v_s_s_ptm = obj.vob_v_e_e_ptm = 1
        self.assertEqual(obj.size, 1)
        self.assertEqual(obj.vob_v_s_s_ptm, 1)
        self.assertEqual(obj.vob_v_e_e_ptm, 1)
        obj.vob_a[0].stp_ptm1 = obj.vob_a[0].stp_ptm2 = obj.vob_a[0].gap_len1 = obj.vob_a[0].gap_len2 = 1
        self.assertEqual(obj.vob_a[0].stp_ptm1, 1)
        self.assertEqual(obj.vob_a[0].stp_ptm2, 1)
        self.assertEqual(obj.vob_a[0].gap_len1, 1)
        self.assertEqual(obj.vob_a[0].gap_len2, 1)

    def test_sml_agl_data_t(self):
        obj = nav_types.sml_agl_data_t()
        obj.address = obj.size = 1
        self.assertEqual(obj.address, 1)
        self.assertEqual(obj.size, 1)

    def test_sml_agli_t(self):
        obj = nav_types.sml_agli_t()
        temp = nav_types.sml_agl_data_t()
        temp.address = 1
        obj.data[0].address = 0
        obj.set_data(0, temp)
        self.assertEqual(obj.data[0].address, 1)
        temp = []
        for i in range(9):
            temp.append(nav_types.sml_agl_data_t())
            temp[i].address = i
        obj.data = temp
        for i in range(9):
            self.assertEqual(obj.data[i].address, i)

    def test_vobu_sri_t(self):
        obj = nav_types.vobu_sri_t()
        obj.next_video = obj.next_vobu = obj.prev_vobu = obj.prev_video = 1
        self.assertEqual(obj.next_video, 1)
        self.assertEqual(obj.next_vobu, 1)
        self.assertEqual(obj.prev_vobu, 1)
        self.assertEqual(obj.prev_video, 1)
        obj.set_fwda(0, 1)
        self.assertEqual(obj.fwda[0], 1)
        obj.fwda = range(19)
        self.assertEqual(obj.fwda, range(19))
        obj.set_bwda(0, 1)
        self.assertEqual(obj.bwda[0], 1)
        obj.bwda = range(19)
        self.assertEqual(obj.bwda, range(19))

    def test_synci_t(self):
        obj = nav_types.synci_t()
        obj.set_a_synca(0, 1)
        self.assertEqual(obj.a_synca[0], 1)
        obj.a_synca = range(8)
        self.assertEqual(obj.a_synca, range(8))
        obj.set_sp_synca(0, 1)
        self.assertEqual(obj.sp_synca[0], 1)
        obj.sp_synca = range(32)
        self.assertEqual(obj.sp_synca, range(32))

    def test_dsi_t(self):
        obj = nav_types.dsi_t()
        obj.set_zero1(0, 1)
        self.assertEqual(obj.zero1[0], 1)
        temp = []
        for i in xrange(471):
            temp.append(1)
        obj.zero1 = temp
        self.assertEqual(obj.zero1, temp)
        temp = nav_types.dsi_gi_t()
        temp.vobu_ea = 1
        obj.dsi_gi.vobu_ea = 0
        obj.dsi_gi = temp
        self.assertEqual(obj.dsi_gi.vobu_ea, 1)
        temp = nav_types.sml_pbi_t()
        temp.size = 1
        obj.sml_pbi.size = 0
        obj.sml_pbi = temp
        self.assertEqual(obj.sml_pbi.size, 1)
        obj.sml_agli = nav_types.sml_agli_t()
        temp = nav_types.vobu_sri_t()
        temp.next_video = 1
        obj.vobu_sri.next_video = 0
        obj.vobu_sri = temp
        self.assertEqual(obj.vobu_sri.next_video, 1)
        temp = nav_types.synci_t()
        temp.set_a_synca(0,1)
        obj.synci.set_a_synca(0,0)
        obj.synci = temp
        self.assertEqual(obj.synci.a_synca[0], 1)

# Run the tests
if __name__ == '__main__':
    unittest.main()




