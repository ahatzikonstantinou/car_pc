from brisa.core.reactors import GLib2Reactor
reactor = GLib2Reactor()






if __name__ == '__main__':
   igd = IGD()
   igd += 
   reactor.main()
